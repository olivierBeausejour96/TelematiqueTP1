﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VersionOfficielle
{
    public static class CAllInPokerGame
    {
        public enum Position { CO = 2, DEALER = 3, SB = 0, BB = 1 };
    }
}
