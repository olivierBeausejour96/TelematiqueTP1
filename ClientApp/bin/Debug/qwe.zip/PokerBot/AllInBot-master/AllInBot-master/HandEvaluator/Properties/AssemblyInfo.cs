﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Permissions;

[assembly: FileIOPermission(SecurityAction.RequestMinimum)]
[assembly: AssemblyTitle("HandEvaluator")]
[assembly: AssemblyDescription("This assembly is released under the LGPL software license.")]
[assembly: AssemblyCopyright("Copyright © Keith Rule 2005-2007")]
[assembly: ComVisible(false)]
[assembly: CLSCompliant(false)]
[assembly: Guid("e98a3374-314d-4597-bfb7-bce75bb7bef6")]
[assembly: AssemblyVersion("2.0.0.0")]
[assembly: AssemblyFileVersion("2.0.0.0")]
