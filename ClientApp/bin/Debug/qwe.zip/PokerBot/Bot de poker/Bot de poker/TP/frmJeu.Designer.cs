﻿namespace TP
{
    partial class frmJeu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmJeu));
            this.lblJoueur1 = new System.Windows.Forms.Label();
            this.btnRaise = new System.Windows.Forms.Button();
            this.txtNbJetons = new System.Windows.Forms.TextBox();
            this.btnPot = new System.Windows.Forms.Button();
            this.btnHalfPot = new System.Windows.Forms.Button();
            this.btnTwoThirdPot = new System.Windows.Forms.Button();
            this.btnMax = new System.Windows.Forms.Button();
            this.btnFold = new System.Windows.Forms.Button();
            this.btnCall = new System.Windows.Forms.Button();
            this.lblPot = new System.Windows.Forms.Label();
            this.lblJoueur1Jeton = new System.Windows.Forms.Label();
            this.lblJoueur2Jeton = new System.Windows.Forms.Label();
            this.lblJoueur3Jeton = new System.Windows.Forms.Label();
            this.lblJoueur4Jeton = new System.Windows.Forms.Label();
            this.lblJoueur5Jeton = new System.Windows.Forms.Label();
            this.lblJoueur6Jeton = new System.Windows.Forms.Label();
            this.btnCheck = new System.Windows.Forms.Button();
            this.lblChoix2 = new System.Windows.Forms.Label();
            this.lblChoix1 = new System.Windows.Forms.Label();
            this.lblChoix3 = new System.Windows.Forms.Label();
            this.lblChoix4 = new System.Windows.Forms.Label();
            this.lblChoix5 = new System.Windows.Forms.Label();
            this.lblChoix6 = new System.Windows.Forms.Label();
            this.btnBet = new System.Windows.Forms.Button();
            this.lblJoueur3 = new System.Windows.Forms.Label();
            this.lblJoueur5 = new System.Windows.Forms.Label();
            this.lblJoueur4 = new System.Windows.Forms.Label();
            this.lblJoueur2 = new System.Windows.Forms.Label();
            this.lblJoueur6 = new System.Windows.Forms.Label();
            this.picDealer = new System.Windows.Forms.PictureBox();
            this.picCarte62 = new System.Windows.Forms.PictureBox();
            this.picCarte61 = new System.Windows.Forms.PictureBox();
            this.picCarte52 = new System.Windows.Forms.PictureBox();
            this.picCarte51 = new System.Windows.Forms.PictureBox();
            this.picCarte42 = new System.Windows.Forms.PictureBox();
            this.picCarte41 = new System.Windows.Forms.PictureBox();
            this.picCarte32 = new System.Windows.Forms.PictureBox();
            this.picCarte31 = new System.Windows.Forms.PictureBox();
            this.picCarte22 = new System.Windows.Forms.PictureBox();
            this.picCarte21 = new System.Windows.Forms.PictureBox();
            this.picCarte11 = new System.Windows.Forms.PictureBox();
            this.picCarte12 = new System.Windows.Forms.PictureBox();
            this.picNoir6 = new System.Windows.Forms.PictureBox();
            this.picNoir5 = new System.Windows.Forms.PictureBox();
            this.picNoir4 = new System.Windows.Forms.PictureBox();
            this.picNoir3 = new System.Windows.Forms.PictureBox();
            this.picNoir2 = new System.Windows.Forms.PictureBox();
            this.picNoir1 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.picBoardCarte1 = new System.Windows.Forms.PictureBox();
            this.picBoardCarte2 = new System.Windows.Forms.PictureBox();
            this.picBoardCarte3 = new System.Windows.Forms.PictureBox();
            this.picBoardCarte4 = new System.Windows.Forms.PictureBox();
            this.picBoardCarte5 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picDealer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCarte62)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCarte61)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCarte52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCarte51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCarte42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCarte41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCarte32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCarte31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCarte22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCarte21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCarte11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCarte12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNoir6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNoir5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNoir4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNoir3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNoir2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNoir1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoardCarte1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoardCarte2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoardCarte3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoardCarte4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoardCarte5)).BeginInit();
            this.SuspendLayout();
            // 
            // lblJoueur1
            // 
            this.lblJoueur1.AutoSize = true;
            this.lblJoueur1.BackColor = System.Drawing.SystemColors.WindowText;
            this.lblJoueur1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJoueur1.ForeColor = System.Drawing.Color.Chartreuse;
            this.lblJoueur1.Location = new System.Drawing.Point(351, 393);
            this.lblJoueur1.Name = "lblJoueur1";
            this.lblJoueur1.Size = new System.Drawing.Size(55, 14);
            this.lblJoueur1.TabIndex = 10;
            this.lblJoueur1.Text = "Joueur 1";
            // 
            // btnRaise
            // 
            this.btnRaise.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnRaise.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRaise.ForeColor = System.Drawing.SystemColors.Window;
            this.btnRaise.Location = new System.Drawing.Point(880, 509);
            this.btnRaise.Name = "btnRaise";
            this.btnRaise.Size = new System.Drawing.Size(178, 56);
            this.btnRaise.TabIndex = 16;
            this.btnRaise.Text = "Raise";
            this.btnRaise.UseVisualStyleBackColor = false;
            this.btnRaise.Click += new System.EventHandler(this.btnRaise_Click);
            // 
            // txtNbJetons
            // 
            this.txtNbJetons.BackColor = System.Drawing.Color.Black;
            this.txtNbJetons.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNbJetons.ForeColor = System.Drawing.Color.White;
            this.txtNbJetons.Location = new System.Drawing.Point(902, 476);
            this.txtNbJetons.Name = "txtNbJetons";
            this.txtNbJetons.Size = new System.Drawing.Size(180, 20);
            this.txtNbJetons.TabIndex = 17;
            this.txtNbJetons.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNbJeton_KeyPress);
            this.txtNbJetons.Leave += new System.EventHandler(this.txtNbJeton_Leave);
            // 
            // btnPot
            // 
            this.btnPot.BackColor = System.Drawing.Color.Black;
            this.btnPot.ForeColor = System.Drawing.Color.White;
            this.btnPot.Location = new System.Drawing.Point(995, 435);
            this.btnPot.Name = "btnPot";
            this.btnPot.Size = new System.Drawing.Size(40, 35);
            this.btnPot.TabIndex = 18;
            this.btnPot.Tag = "3/3";
            this.btnPot.Text = "Pot";
            this.btnPot.UseVisualStyleBackColor = false;
            this.btnPot.EnabledChanged += new System.EventHandler(this.btnHalfPot_EnabledChanged);
            this.btnPot.Click += new System.EventHandler(this.btnPot_Click);
            // 
            // btnHalfPot
            // 
            this.btnHalfPot.BackColor = System.Drawing.Color.Black;
            this.btnHalfPot.ForeColor = System.Drawing.Color.White;
            this.btnHalfPot.Location = new System.Drawing.Point(902, 434);
            this.btnHalfPot.Name = "btnHalfPot";
            this.btnHalfPot.Size = new System.Drawing.Size(40, 35);
            this.btnHalfPot.TabIndex = 19;
            this.btnHalfPot.Tag = "1/2";
            this.btnHalfPot.Text = "1/2 pot";
            this.btnHalfPot.UseVisualStyleBackColor = false;
            this.btnHalfPot.EnabledChanged += new System.EventHandler(this.btnHalfPot_EnabledChanged);
            this.btnHalfPot.Click += new System.EventHandler(this.btnHalfPot_Click);
            // 
            // btnTwoThirdPot
            // 
            this.btnTwoThirdPot.BackColor = System.Drawing.Color.Black;
            this.btnTwoThirdPot.ForeColor = System.Drawing.Color.White;
            this.btnTwoThirdPot.Location = new System.Drawing.Point(949, 434);
            this.btnTwoThirdPot.Name = "btnTwoThirdPot";
            this.btnTwoThirdPot.Size = new System.Drawing.Size(40, 35);
            this.btnTwoThirdPot.TabIndex = 20;
            this.btnTwoThirdPot.Tag = "2/3";
            this.btnTwoThirdPot.Text = "2/3 pot";
            this.btnTwoThirdPot.UseVisualStyleBackColor = false;
            this.btnTwoThirdPot.EnabledChanged += new System.EventHandler(this.btnHalfPot_EnabledChanged);
            this.btnTwoThirdPot.Click += new System.EventHandler(this.btnTwoThirdPot_Click);
            // 
            // btnMax
            // 
            this.btnMax.BackColor = System.Drawing.Color.Black;
            this.btnMax.ForeColor = System.Drawing.Color.White;
            this.btnMax.Location = new System.Drawing.Point(1042, 435);
            this.btnMax.Name = "btnMax";
            this.btnMax.Size = new System.Drawing.Size(40, 34);
            this.btnMax.TabIndex = 21;
            this.btnMax.Tag = "4/3";
            this.btnMax.Text = "Max";
            this.btnMax.UseVisualStyleBackColor = false;
            this.btnMax.EnabledChanged += new System.EventHandler(this.btnHalfPot_EnabledChanged);
            this.btnMax.Click += new System.EventHandler(this.btnMax_Click);
            // 
            // btnFold
            // 
            this.btnFold.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnFold.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFold.ForeColor = System.Drawing.SystemColors.Window;
            this.btnFold.Location = new System.Drawing.Point(150, 509);
            this.btnFold.Name = "btnFold";
            this.btnFold.Size = new System.Drawing.Size(178, 56);
            this.btnFold.TabIndex = 22;
            this.btnFold.Text = "Fold";
            this.btnFold.UseVisualStyleBackColor = false;
            this.btnFold.Click += new System.EventHandler(this.btnFold_Click);
            // 
            // btnCall
            // 
            this.btnCall.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnCall.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCall.ForeColor = System.Drawing.SystemColors.Window;
            this.btnCall.Location = new System.Drawing.Point(505, 509);
            this.btnCall.Name = "btnCall";
            this.btnCall.Size = new System.Drawing.Size(178, 56);
            this.btnCall.TabIndex = 23;
            this.btnCall.Text = "Call";
            this.btnCall.UseVisualStyleBackColor = false;
            this.btnCall.Click += new System.EventHandler(this.btnCall_Click);
            // 
            // lblPot
            // 
            this.lblPot.AutoSize = true;
            this.lblPot.BackColor = System.Drawing.SystemColors.WindowText;
            this.lblPot.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblPot.ForeColor = System.Drawing.Color.Chartreuse;
            this.lblPot.Location = new System.Drawing.Point(518, 149);
            this.lblPot.Name = "lblPot";
            this.lblPot.Size = new System.Drawing.Size(52, 14);
            this.lblPot.TabIndex = 24;
            this.lblPot.Text = "Pot: XXX";
            // 
            // lblJoueur1Jeton
            // 
            this.lblJoueur1Jeton.AutoSize = true;
            this.lblJoueur1Jeton.BackColor = System.Drawing.SystemColors.WindowText;
            this.lblJoueur1Jeton.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJoueur1Jeton.ForeColor = System.Drawing.Color.Chartreuse;
            this.lblJoueur1Jeton.Location = new System.Drawing.Point(371, 415);
            this.lblJoueur1Jeton.Name = "lblJoueur1Jeton";
            this.lblJoueur1Jeton.Size = new System.Drawing.Size(13, 14);
            this.lblJoueur1Jeton.TabIndex = 33;
            this.lblJoueur1Jeton.Text = "0";
            // 
            // lblJoueur2Jeton
            // 
            this.lblJoueur2Jeton.AutoSize = true;
            this.lblJoueur2Jeton.BackColor = System.Drawing.SystemColors.WindowText;
            this.lblJoueur2Jeton.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblJoueur2Jeton.ForeColor = System.Drawing.Color.Chartreuse;
            this.lblJoueur2Jeton.Location = new System.Drawing.Point(67, 336);
            this.lblJoueur2Jeton.Name = "lblJoueur2Jeton";
            this.lblJoueur2Jeton.Size = new System.Drawing.Size(13, 14);
            this.lblJoueur2Jeton.TabIndex = 34;
            this.lblJoueur2Jeton.Text = "0";
            // 
            // lblJoueur3Jeton
            // 
            this.lblJoueur3Jeton.AutoSize = true;
            this.lblJoueur3Jeton.BackColor = System.Drawing.SystemColors.WindowText;
            this.lblJoueur3Jeton.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJoueur3Jeton.ForeColor = System.Drawing.Color.Chartreuse;
            this.lblJoueur3Jeton.Location = new System.Drawing.Point(93, 101);
            this.lblJoueur3Jeton.Name = "lblJoueur3Jeton";
            this.lblJoueur3Jeton.Size = new System.Drawing.Size(13, 14);
            this.lblJoueur3Jeton.TabIndex = 35;
            this.lblJoueur3Jeton.Text = "0";
            // 
            // lblJoueur4Jeton
            // 
            this.lblJoueur4Jeton.AutoSize = true;
            this.lblJoueur4Jeton.BackColor = System.Drawing.SystemColors.WindowText;
            this.lblJoueur4Jeton.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblJoueur4Jeton.ForeColor = System.Drawing.Color.Chartreuse;
            this.lblJoueur4Jeton.Location = new System.Drawing.Point(954, 120);
            this.lblJoueur4Jeton.Name = "lblJoueur4Jeton";
            this.lblJoueur4Jeton.Size = new System.Drawing.Size(13, 14);
            this.lblJoueur4Jeton.TabIndex = 36;
            this.lblJoueur4Jeton.Text = "0";
            // 
            // lblJoueur5Jeton
            // 
            this.lblJoueur5Jeton.AutoSize = true;
            this.lblJoueur5Jeton.BackColor = System.Drawing.SystemColors.WindowText;
            this.lblJoueur5Jeton.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJoueur5Jeton.ForeColor = System.Drawing.Color.Chartreuse;
            this.lblJoueur5Jeton.Location = new System.Drawing.Point(970, 336);
            this.lblJoueur5Jeton.Name = "lblJoueur5Jeton";
            this.lblJoueur5Jeton.Size = new System.Drawing.Size(13, 14);
            this.lblJoueur5Jeton.TabIndex = 37;
            this.lblJoueur5Jeton.Text = "0";
            // 
            // lblJoueur6Jeton
            // 
            this.lblJoueur6Jeton.AutoSize = true;
            this.lblJoueur6Jeton.BackColor = System.Drawing.SystemColors.WindowText;
            this.lblJoueur6Jeton.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJoueur6Jeton.ForeColor = System.Drawing.Color.Chartreuse;
            this.lblJoueur6Jeton.Location = new System.Drawing.Point(744, 415);
            this.lblJoueur6Jeton.Name = "lblJoueur6Jeton";
            this.lblJoueur6Jeton.Size = new System.Drawing.Size(13, 14);
            this.lblJoueur6Jeton.TabIndex = 38;
            this.lblJoueur6Jeton.Text = "0";
            // 
            // btnCheck
            // 
            this.btnCheck.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnCheck.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheck.ForeColor = System.Drawing.SystemColors.Window;
            this.btnCheck.Location = new System.Drawing.Point(334, 509);
            this.btnCheck.Name = "btnCheck";
            this.btnCheck.Size = new System.Drawing.Size(165, 56);
            this.btnCheck.TabIndex = 46;
            this.btnCheck.Text = "Check";
            this.btnCheck.UseVisualStyleBackColor = false;
            this.btnCheck.Click += new System.EventHandler(this.btnCheck_Click);
            // 
            // lblChoix2
            // 
            this.lblChoix2.AutoSize = true;
            this.lblChoix2.BackColor = System.Drawing.Color.Black;
            this.lblChoix2.Enabled = false;
            this.lblChoix2.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChoix2.ForeColor = System.Drawing.Color.Chartreuse;
            this.lblChoix2.Location = new System.Drawing.Point(196, 245);
            this.lblChoix2.Name = "lblChoix2";
            this.lblChoix2.Size = new System.Drawing.Size(74, 14);
            this.lblChoix2.TabIndex = 72;
            this.lblChoix2.Text = "Aucun choix";
            this.lblChoix2.Visible = false;
            // 
            // lblChoix1
            // 
            this.lblChoix1.AutoSize = true;
            this.lblChoix1.BackColor = System.Drawing.Color.Black;
            this.lblChoix1.Enabled = false;
            this.lblChoix1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChoix1.ForeColor = System.Drawing.Color.Chartreuse;
            this.lblChoix1.Location = new System.Drawing.Point(321, 277);
            this.lblChoix1.Name = "lblChoix1";
            this.lblChoix1.Size = new System.Drawing.Size(74, 14);
            this.lblChoix1.TabIndex = 73;
            this.lblChoix1.Text = "Aucun choix";
            this.lblChoix1.Visible = false;
            // 
            // lblChoix3
            // 
            this.lblChoix3.AutoSize = true;
            this.lblChoix3.BackColor = System.Drawing.SystemColors.WindowText;
            this.lblChoix3.Enabled = false;
            this.lblChoix3.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblChoix3.ForeColor = System.Drawing.Color.Chartreuse;
            this.lblChoix3.Location = new System.Drawing.Point(240, 149);
            this.lblChoix3.Name = "lblChoix3";
            this.lblChoix3.Size = new System.Drawing.Size(74, 14);
            this.lblChoix3.TabIndex = 74;
            this.lblChoix3.Text = "Aucun choix";
            this.lblChoix3.Visible = false;
            // 
            // lblChoix4
            // 
            this.lblChoix4.AutoSize = true;
            this.lblChoix4.BackColor = System.Drawing.SystemColors.WindowText;
            this.lblChoix4.Enabled = false;
            this.lblChoix4.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChoix4.ForeColor = System.Drawing.Color.Chartreuse;
            this.lblChoix4.Location = new System.Drawing.Point(683, 133);
            this.lblChoix4.Name = "lblChoix4";
            this.lblChoix4.Size = new System.Drawing.Size(74, 14);
            this.lblChoix4.TabIndex = 75;
            this.lblChoix4.Text = "Aucun choix";
            this.lblChoix4.Visible = false;
            // 
            // lblChoix5
            // 
            this.lblChoix5.AutoSize = true;
            this.lblChoix5.BackColor = System.Drawing.SystemColors.WindowText;
            this.lblChoix5.Enabled = false;
            this.lblChoix5.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblChoix5.ForeColor = System.Drawing.Color.Chartreuse;
            this.lblChoix5.Location = new System.Drawing.Point(803, 245);
            this.lblChoix5.Name = "lblChoix5";
            this.lblChoix5.Size = new System.Drawing.Size(74, 14);
            this.lblChoix5.TabIndex = 76;
            this.lblChoix5.Text = "Aucun choix";
            this.lblChoix5.Visible = false;
            // 
            // lblChoix6
            // 
            this.lblChoix6.AutoSize = true;
            this.lblChoix6.BackColor = System.Drawing.Color.Black;
            this.lblChoix6.Enabled = false;
            this.lblChoix6.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblChoix6.ForeColor = System.Drawing.Color.Chartreuse;
            this.lblChoix6.Location = new System.Drawing.Point(705, 277);
            this.lblChoix6.Name = "lblChoix6";
            this.lblChoix6.Size = new System.Drawing.Size(74, 14);
            this.lblChoix6.TabIndex = 77;
            this.lblChoix6.Text = "Aucun choix";
            this.lblChoix6.Visible = false;
            // 
            // btnBet
            // 
            this.btnBet.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnBet.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBet.ForeColor = System.Drawing.SystemColors.Window;
            this.btnBet.Location = new System.Drawing.Point(689, 509);
            this.btnBet.Name = "btnBet";
            this.btnBet.Size = new System.Drawing.Size(178, 56);
            this.btnBet.TabIndex = 78;
            this.btnBet.Text = "Bet";
            this.btnBet.UseVisualStyleBackColor = false;
            this.btnBet.Click += new System.EventHandler(this.btnBet_Click);
            // 
            // lblJoueur3
            // 
            this.lblJoueur3.AutoSize = true;
            this.lblJoueur3.BackColor = System.Drawing.SystemColors.WindowText;
            this.lblJoueur3.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblJoueur3.ForeColor = System.Drawing.Color.Chartreuse;
            this.lblJoueur3.Location = new System.Drawing.Point(79, 83);
            this.lblJoueur3.Name = "lblJoueur3";
            this.lblJoueur3.Size = new System.Drawing.Size(55, 14);
            this.lblJoueur3.TabIndex = 79;
            this.lblJoueur3.Text = "Joueur 3";
            // 
            // lblJoueur5
            // 
            this.lblJoueur5.AutoSize = true;
            this.lblJoueur5.BackColor = System.Drawing.SystemColors.WindowText;
            this.lblJoueur5.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblJoueur5.ForeColor = System.Drawing.Color.Chartreuse;
            this.lblJoueur5.Location = new System.Drawing.Point(954, 314);
            this.lblJoueur5.Name = "lblJoueur5";
            this.lblJoueur5.Size = new System.Drawing.Size(55, 14);
            this.lblJoueur5.TabIndex = 80;
            this.lblJoueur5.Text = "Joueur 5";
            // 
            // lblJoueur4
            // 
            this.lblJoueur4.AutoSize = true;
            this.lblJoueur4.BackColor = System.Drawing.SystemColors.WindowText;
            this.lblJoueur4.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblJoueur4.ForeColor = System.Drawing.Color.Chartreuse;
            this.lblJoueur4.Location = new System.Drawing.Point(936, 98);
            this.lblJoueur4.Name = "lblJoueur4";
            this.lblJoueur4.Size = new System.Drawing.Size(55, 14);
            this.lblJoueur4.TabIndex = 81;
            this.lblJoueur4.Text = "Joueur 4";
            // 
            // lblJoueur2
            // 
            this.lblJoueur2.AutoSize = true;
            this.lblJoueur2.BackColor = System.Drawing.SystemColors.WindowText;
            this.lblJoueur2.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJoueur2.ForeColor = System.Drawing.Color.Chartreuse;
            this.lblJoueur2.Location = new System.Drawing.Point(47, 314);
            this.lblJoueur2.Name = "lblJoueur2";
            this.lblJoueur2.Size = new System.Drawing.Size(55, 14);
            this.lblJoueur2.TabIndex = 82;
            this.lblJoueur2.Text = "Joueur 2";
            // 
            // lblJoueur6
            // 
            this.lblJoueur6.AutoSize = true;
            this.lblJoueur6.BackColor = System.Drawing.SystemColors.WindowText;
            this.lblJoueur6.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblJoueur6.ForeColor = System.Drawing.Color.Chartreuse;
            this.lblJoueur6.Location = new System.Drawing.Point(724, 393);
            this.lblJoueur6.Name = "lblJoueur6";
            this.lblJoueur6.Size = new System.Drawing.Size(55, 14);
            this.lblJoueur6.TabIndex = 83;
            this.lblJoueur6.Text = "Joueur 6";
            // 
            // picDealer
            // 
            this.picDealer.BackColor = System.Drawing.SystemColors.WindowText;
            this.picDealer.Image = global::TP.Properties.Resources.dealer;
            this.picDealer.Location = new System.Drawing.Point(661, 299);
            this.picDealer.Name = "picDealer";
            this.picDealer.Size = new System.Drawing.Size(33, 29);
            this.picDealer.TabIndex = 85;
            this.picDealer.TabStop = false;
            // 
            // picCarte62
            // 
            this.picCarte62.BackColor = System.Drawing.SystemColors.WindowText;
            this.picCarte62.Enabled = false;
            this.picCarte62.Location = new System.Drawing.Point(763, 298);
            this.picCarte62.Name = "picCarte62";
            this.picCarte62.Size = new System.Drawing.Size(57, 74);
            this.picCarte62.TabIndex = 68;
            this.picCarte62.TabStop = false;
            this.picCarte62.Visible = false;
            // 
            // picCarte61
            // 
            this.picCarte61.BackColor = System.Drawing.SystemColors.WindowText;
            this.picCarte61.Enabled = false;
            this.picCarte61.Location = new System.Drawing.Point(700, 298);
            this.picCarte61.Name = "picCarte61";
            this.picCarte61.Size = new System.Drawing.Size(57, 74);
            this.picCarte61.TabIndex = 67;
            this.picCarte61.TabStop = false;
            this.picCarte61.Visible = false;
            // 
            // picCarte52
            // 
            this.picCarte52.BackColor = System.Drawing.SystemColors.WindowText;
            this.picCarte52.Enabled = false;
            this.picCarte52.Location = new System.Drawing.Point(995, 218);
            this.picCarte52.Name = "picCarte52";
            this.picCarte52.Size = new System.Drawing.Size(57, 74);
            this.picCarte52.TabIndex = 63;
            this.picCarte52.TabStop = false;
            this.picCarte52.Visible = false;
            // 
            // picCarte51
            // 
            this.picCarte51.BackColor = System.Drawing.SystemColors.WindowText;
            this.picCarte51.Enabled = false;
            this.picCarte51.Location = new System.Drawing.Point(932, 218);
            this.picCarte51.Name = "picCarte51";
            this.picCarte51.Size = new System.Drawing.Size(57, 74);
            this.picCarte51.TabIndex = 62;
            this.picCarte51.TabStop = false;
            this.picCarte51.Visible = false;
            // 
            // picCarte42
            // 
            this.picCarte42.BackColor = System.Drawing.SystemColors.WindowText;
            this.picCarte42.Enabled = false;
            this.picCarte42.Location = new System.Drawing.Point(826, 83);
            this.picCarte42.Name = "picCarte42";
            this.picCarte42.Size = new System.Drawing.Size(57, 74);
            this.picCarte42.TabIndex = 58;
            this.picCarte42.TabStop = false;
            this.picCarte42.Visible = false;
            // 
            // picCarte41
            // 
            this.picCarte41.BackColor = System.Drawing.SystemColors.WindowText;
            this.picCarte41.Enabled = false;
            this.picCarte41.Location = new System.Drawing.Point(763, 83);
            this.picCarte41.Name = "picCarte41";
            this.picCarte41.Size = new System.Drawing.Size(57, 74);
            this.picCarte41.TabIndex = 57;
            this.picCarte41.TabStop = false;
            this.picCarte41.Visible = false;
            // 
            // picCarte32
            // 
            this.picCarte32.BackColor = System.Drawing.SystemColors.WindowText;
            this.picCarte32.Enabled = false;
            this.picCarte32.Location = new System.Drawing.Point(276, 60);
            this.picCarte32.Name = "picCarte32";
            this.picCarte32.Size = new System.Drawing.Size(57, 74);
            this.picCarte32.TabIndex = 53;
            this.picCarte32.TabStop = false;
            this.picCarte32.Visible = false;
            // 
            // picCarte31
            // 
            this.picCarte31.BackColor = System.Drawing.SystemColors.WindowText;
            this.picCarte31.Enabled = false;
            this.picCarte31.Location = new System.Drawing.Point(213, 60);
            this.picCarte31.Name = "picCarte31";
            this.picCarte31.Size = new System.Drawing.Size(57, 74);
            this.picCarte31.TabIndex = 52;
            this.picCarte31.TabStop = false;
            this.picCarte31.Visible = false;
            // 
            // picCarte22
            // 
            this.picCarte22.BackColor = System.Drawing.SystemColors.WindowText;
            this.picCarte22.Enabled = false;
            this.picCarte22.Location = new System.Drawing.Point(86, 218);
            this.picCarte22.Name = "picCarte22";
            this.picCarte22.Size = new System.Drawing.Size(57, 74);
            this.picCarte22.TabIndex = 48;
            this.picCarte22.TabStop = false;
            this.picCarte22.Visible = false;
            // 
            // picCarte21
            // 
            this.picCarte21.BackColor = System.Drawing.SystemColors.WindowText;
            this.picCarte21.Enabled = false;
            this.picCarte21.Location = new System.Drawing.Point(23, 217);
            this.picCarte21.Name = "picCarte21";
            this.picCarte21.Size = new System.Drawing.Size(57, 74);
            this.picCarte21.TabIndex = 47;
            this.picCarte21.TabStop = false;
            this.picCarte21.Visible = false;
            // 
            // picCarte11
            // 
            this.picCarte11.BackColor = System.Drawing.SystemColors.WindowText;
            this.picCarte11.Enabled = false;
            this.picCarte11.Location = new System.Drawing.Point(376, 298);
            this.picCarte11.Name = "picCarte11";
            this.picCarte11.Size = new System.Drawing.Size(57, 74);
            this.picCarte11.TabIndex = 43;
            this.picCarte11.TabStop = false;
            this.picCarte11.Visible = false;
            // 
            // picCarte12
            // 
            this.picCarte12.BackColor = System.Drawing.SystemColors.WindowText;
            this.picCarte12.Enabled = false;
            this.picCarte12.Location = new System.Drawing.Point(312, 298);
            this.picCarte12.Name = "picCarte12";
            this.picCarte12.Size = new System.Drawing.Size(57, 74);
            this.picCarte12.TabIndex = 42;
            this.picCarte12.TabStop = false;
            this.picCarte12.Visible = false;
            // 
            // picNoir6
            // 
            this.picNoir6.BackColor = System.Drawing.SystemColors.WindowText;
            this.picNoir6.BackgroundImage = global::TP.Properties.Resources.imgJoueur;
            this.picNoir6.Location = new System.Drawing.Point(689, 378);
            this.picNoir6.Name = "picNoir6";
            this.picNoir6.Size = new System.Drawing.Size(166, 64);
            this.picNoir6.TabIndex = 32;
            this.picNoir6.TabStop = false;
            // 
            // picNoir5
            // 
            this.picNoir5.BackColor = System.Drawing.SystemColors.WindowText;
            this.picNoir5.BackgroundImage = global::TP.Properties.Resources.imgJoueur;
            this.picNoir5.Location = new System.Drawing.Point(917, 298);
            this.picNoir5.Name = "picNoir5";
            this.picNoir5.Size = new System.Drawing.Size(166, 64);
            this.picNoir5.TabIndex = 31;
            this.picNoir5.TabStop = false;
            // 
            // picNoir4
            // 
            this.picNoir4.BackColor = System.Drawing.SystemColors.WindowText;
            this.picNoir4.BackgroundImage = global::TP.Properties.Resources.imgJoueur;
            this.picNoir4.Location = new System.Drawing.Point(902, 83);
            this.picNoir4.Name = "picNoir4";
            this.picNoir4.Size = new System.Drawing.Size(166, 64);
            this.picNoir4.TabIndex = 30;
            this.picNoir4.TabStop = false;
            // 
            // picNoir3
            // 
            this.picNoir3.BackColor = System.Drawing.SystemColors.WindowText;
            this.picNoir3.BackgroundImage = global::TP.Properties.Resources.imgJoueur;
            this.picNoir3.Location = new System.Drawing.Point(41, 66);
            this.picNoir3.Name = "picNoir3";
            this.picNoir3.Size = new System.Drawing.Size(166, 64);
            this.picNoir3.TabIndex = 29;
            this.picNoir3.TabStop = false;
            // 
            // picNoir2
            // 
            this.picNoir2.BackColor = System.Drawing.SystemColors.WindowText;
            this.picNoir2.BackgroundImage = global::TP.Properties.Resources.imgJoueur;
            this.picNoir2.Location = new System.Drawing.Point(12, 298);
            this.picNoir2.Name = "picNoir2";
            this.picNoir2.Size = new System.Drawing.Size(166, 64);
            this.picNoir2.TabIndex = 28;
            this.picNoir2.TabStop = false;
            // 
            // picNoir1
            // 
            this.picNoir1.BackColor = System.Drawing.SystemColors.WindowText;
            this.picNoir1.BackgroundImage = global::TP.Properties.Resources.imgJoueur;
            this.picNoir1.Location = new System.Drawing.Point(312, 378);
            this.picNoir1.Name = "picNoir1";
            this.picNoir1.Size = new System.Drawing.Size(166, 64);
            this.picNoir1.TabIndex = 2;
            this.picNoir1.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.WindowText;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-1, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1093, 585);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // picBoardCarte1
            // 
            this.picBoardCarte1.BackColor = System.Drawing.SystemColors.WindowText;
            this.picBoardCarte1.Enabled = false;
            this.picBoardCarte1.Location = new System.Drawing.Point(392, 170);
            this.picBoardCarte1.Name = "picBoardCarte1";
            this.picBoardCarte1.Size = new System.Drawing.Size(57, 74);
            this.picBoardCarte1.TabIndex = 86;
            this.picBoardCarte1.TabStop = false;
            this.picBoardCarte1.Visible = false;
            // 
            // picBoardCarte2
            // 
            this.picBoardCarte2.BackColor = System.Drawing.SystemColors.WindowText;
            this.picBoardCarte2.Enabled = false;
            this.picBoardCarte2.Location = new System.Drawing.Point(455, 170);
            this.picBoardCarte2.Name = "picBoardCarte2";
            this.picBoardCarte2.Size = new System.Drawing.Size(57, 74);
            this.picBoardCarte2.TabIndex = 87;
            this.picBoardCarte2.TabStop = false;
            this.picBoardCarte2.Visible = false;
            // 
            // picBoardCarte3
            // 
            this.picBoardCarte3.BackColor = System.Drawing.SystemColors.WindowText;
            this.picBoardCarte3.Enabled = false;
            this.picBoardCarte3.Location = new System.Drawing.Point(518, 170);
            this.picBoardCarte3.Name = "picBoardCarte3";
            this.picBoardCarte3.Size = new System.Drawing.Size(57, 74);
            this.picBoardCarte3.TabIndex = 88;
            this.picBoardCarte3.TabStop = false;
            this.picBoardCarte3.Visible = false;
            // 
            // picBoardCarte4
            // 
            this.picBoardCarte4.BackColor = System.Drawing.SystemColors.WindowText;
            this.picBoardCarte4.Enabled = false;
            this.picBoardCarte4.Location = new System.Drawing.Point(581, 170);
            this.picBoardCarte4.Name = "picBoardCarte4";
            this.picBoardCarte4.Size = new System.Drawing.Size(57, 74);
            this.picBoardCarte4.TabIndex = 89;
            this.picBoardCarte4.TabStop = false;
            this.picBoardCarte4.Visible = false;
            // 
            // picBoardCarte5
            // 
            this.picBoardCarte5.BackColor = System.Drawing.SystemColors.WindowText;
            this.picBoardCarte5.Enabled = false;
            this.picBoardCarte5.Location = new System.Drawing.Point(644, 170);
            this.picBoardCarte5.Name = "picBoardCarte5";
            this.picBoardCarte5.Size = new System.Drawing.Size(57, 74);
            this.picBoardCarte5.TabIndex = 90;
            this.picBoardCarte5.TabStop = false;
            this.picBoardCarte5.Visible = false;
            // 
            // frmJeu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1094, 585);
            this.Controls.Add(this.picBoardCarte5);
            this.Controls.Add(this.picBoardCarte4);
            this.Controls.Add(this.picBoardCarte3);
            this.Controls.Add(this.picBoardCarte2);
            this.Controls.Add(this.picBoardCarte1);
            this.Controls.Add(this.picDealer);
            this.Controls.Add(this.lblJoueur6);
            this.Controls.Add(this.lblJoueur2);
            this.Controls.Add(this.lblJoueur4);
            this.Controls.Add(this.lblJoueur5);
            this.Controls.Add(this.lblJoueur3);
            this.Controls.Add(this.btnBet);
            this.Controls.Add(this.lblChoix6);
            this.Controls.Add(this.lblChoix5);
            this.Controls.Add(this.lblChoix4);
            this.Controls.Add(this.lblChoix3);
            this.Controls.Add(this.lblChoix1);
            this.Controls.Add(this.lblChoix2);
            this.Controls.Add(this.picCarte62);
            this.Controls.Add(this.picCarte61);
            this.Controls.Add(this.picCarte52);
            this.Controls.Add(this.picCarte51);
            this.Controls.Add(this.picCarte42);
            this.Controls.Add(this.picCarte41);
            this.Controls.Add(this.picCarte32);
            this.Controls.Add(this.picCarte31);
            this.Controls.Add(this.picCarte22);
            this.Controls.Add(this.picCarte21);
            this.Controls.Add(this.btnCheck);
            this.Controls.Add(this.picCarte11);
            this.Controls.Add(this.picCarte12);
            this.Controls.Add(this.lblJoueur6Jeton);
            this.Controls.Add(this.lblJoueur5Jeton);
            this.Controls.Add(this.lblJoueur4Jeton);
            this.Controls.Add(this.lblJoueur3Jeton);
            this.Controls.Add(this.lblJoueur2Jeton);
            this.Controls.Add(this.lblJoueur1Jeton);
            this.Controls.Add(this.picNoir6);
            this.Controls.Add(this.picNoir5);
            this.Controls.Add(this.picNoir4);
            this.Controls.Add(this.picNoir3);
            this.Controls.Add(this.picNoir2);
            this.Controls.Add(this.lblPot);
            this.Controls.Add(this.btnCall);
            this.Controls.Add(this.btnFold);
            this.Controls.Add(this.btnMax);
            this.Controls.Add(this.btnTwoThirdPot);
            this.Controls.Add(this.btnHalfPot);
            this.Controls.Add(this.btnPot);
            this.Controls.Add(this.txtNbJetons);
            this.Controls.Add(this.btnRaise);
            this.Controls.Add(this.lblJoueur1);
            this.Controls.Add(this.picNoir1);
            this.Controls.Add(this.pictureBox1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmJeu";
            this.ShowIcon = false;
            this.Text = "Poker";
            ((System.ComponentModel.ISupportInitialize)(this.picDealer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCarte62)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCarte61)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCarte52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCarte51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCarte42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCarte41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCarte32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCarte31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCarte22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCarte21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCarte11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCarte12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNoir6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNoir5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNoir4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNoir3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNoir2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNoir1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoardCarte1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoardCarte2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoardCarte3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoardCarte4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoardCarte5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox picNoir1;
        private System.Windows.Forms.Label lblJoueur1;
        private System.Windows.Forms.Button btnRaise;
        private System.Windows.Forms.TextBox txtNbJetons;
        private System.Windows.Forms.Button btnPot;
        private System.Windows.Forms.Button btnHalfPot;
        private System.Windows.Forms.Button btnTwoThirdPot;
        private System.Windows.Forms.Button btnMax;
        private System.Windows.Forms.Button btnFold;
        private System.Windows.Forms.Button btnCall;
        private System.Windows.Forms.Label lblPot;
        private System.Windows.Forms.PictureBox picNoir2;
        private System.Windows.Forms.PictureBox picNoir3;
        private System.Windows.Forms.PictureBox picNoir4;
        private System.Windows.Forms.PictureBox picNoir5;
        private System.Windows.Forms.PictureBox picNoir6;
        private System.Windows.Forms.Label lblJoueur1Jeton;
        private System.Windows.Forms.Label lblJoueur2Jeton;
        private System.Windows.Forms.Label lblJoueur3Jeton;
        private System.Windows.Forms.Label lblJoueur4Jeton;
        private System.Windows.Forms.Label lblJoueur5Jeton;
        private System.Windows.Forms.Label lblJoueur6Jeton;
        private System.Windows.Forms.PictureBox picCarte12;
        private System.Windows.Forms.PictureBox picCarte11;
        private System.Windows.Forms.Button btnCheck;
        private System.Windows.Forms.PictureBox picCarte21;
        private System.Windows.Forms.PictureBox picCarte22;
        private System.Windows.Forms.PictureBox picCarte32;
        private System.Windows.Forms.PictureBox picCarte31;
        private System.Windows.Forms.PictureBox picCarte42;
        private System.Windows.Forms.PictureBox picCarte41;
        private System.Windows.Forms.PictureBox picCarte52;
        private System.Windows.Forms.PictureBox picCarte51;
        private System.Windows.Forms.PictureBox picCarte62;
        private System.Windows.Forms.PictureBox picCarte61;
        private System.Windows.Forms.Label lblChoix2;
        private System.Windows.Forms.Label lblChoix1;
        private System.Windows.Forms.Label lblChoix3;
        private System.Windows.Forms.Label lblChoix4;
        private System.Windows.Forms.Label lblChoix5;
        private System.Windows.Forms.Label lblChoix6;
        private System.Windows.Forms.Button btnBet;
        private System.Windows.Forms.Label lblJoueur3;
        private System.Windows.Forms.Label lblJoueur5;
        private System.Windows.Forms.Label lblJoueur4;
        private System.Windows.Forms.Label lblJoueur2;
        private System.Windows.Forms.Label lblJoueur6;
        private System.Windows.Forms.PictureBox picDealer;
        private System.Windows.Forms.PictureBox picBoardCarte1;
        private System.Windows.Forms.PictureBox picBoardCarte2;
        private System.Windows.Forms.PictureBox picBoardCarte3;
        private System.Windows.Forms.PictureBox picBoardCarte4;
        private System.Windows.Forms.PictureBox picBoardCarte5;
    }
}