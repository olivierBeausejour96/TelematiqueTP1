﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace TP
{
    public class CBotEspacejeux : CBotSite
    {
        private volatile bool FFContinuerAJouer;

        public CBotEspacejeux()
        {
            FFContinuerAJouer = false;
        }

        /// <summary>
        /// Démarrer le robot qui ouvre, ferme, détecte notre main, détecte les mises des mains, etc
        /// </summary>
        public override void Demarrer()
        {
            FFContinuerAJouer = true;

            // Je sais ça l'air bizarre, mais avec les threads on peut caller la procédure Arreter() 
            // meme si le while se fait en meme temps.. J'te dis ca juste au cas ou que tu fasse pas wtf i remove this 
            while (FFContinuerAJouer)
            {
                // TODO_H: Faire le bot qui détecte les tables, les ouvres, etc. TU TRANSFÈRES TOUT TON CODE ICI.

                // À NOTER: Ici c'est la "logique" du code. Donc tu devrais appeler pleins de procédures. Le code de cette procédure est pas suposé dépassé ma main.
            }

            throw new NotImplementedException();
        }
        /// <summary>
        /// Arrêter toute action du robot.
        /// </summary>
        public override void Arreter()
        {
            FFContinuerAJouer = false;
        }
        /// <summary>
        /// Effectuer l'action de fold sur le site.
        /// </summary>
        /// <param name="_joueurTable">Table X que l'on accède à l'aide du joueur (le joueur est nous-même). Lire autre code si ce n'est pas clair.</param>
        public override void Fold(CJoueur _joueurTable)
        {
            //TODO_H: Effectuer l'action de fold.
            throw new NotImplementedException();
        }
        /// <summary>
        /// Effectuer l'action de check sur le site.
        /// </summary>
        /// <param name="_joueurTable">Table X que l'on accède à l'aide du joueur (le joueur est nous-même). Lire autre code si ce n'est pas clair.</param>
        public override void Check(CJoueur _joueurTable)
        {
            //TODO_H: Effectuer l'action de check.
            throw new NotImplementedException();
        }
        /// <summary>
        /// Effectuer l'action de bet sur le site.
        /// </summary>
        /// <param name="_joueurTable">Table X que l'on accède à l'aide du joueur (le joueur est nous-même). Lire autre code si ce n'est pas clair.</param>
        public override void Bet(CJoueur _joueurTable)
        {
            //TODO_H: Effectuer l'action de bet.
            throw new NotImplementedException();
        }
        /// <summary>
        /// Effectuer l'action de call sur le site.
        /// </summary>
        /// <param name="_joueurTable">Table X que l'on accède à l'aide du joueur (le joueur est nous-même). Lire autre code si ce n'est pas clair.</param>
        public override void Call(CJoueur _joueurTable)
        {
            //TODO_H: Effectuer l'action de call.
            throw new NotImplementedException();
        }
        /// <summary>
        /// Effectuer l'action de raise sur le site.
        /// </summary>
        /// <param name="_joueurTable">Table X que l'on accède à l'aide du joueur (le joueur est nous-même). Lire autre code si ce n'est pas clair.</param>
        public override void Raise(CJoueur _joueurTable)
        {
            //TODO_H: Effectuer l'action de raise.
            throw new NotImplementedException();
        }
    }
}
