﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using System.Globalization;

namespace TP
{
    public partial class frmJeu : Form
    {
        public enum DEALER_POS { SB = 0, BB = 1, UTG = 2, MP = 3, CO = 4, BTN = 5};
        public enum DEALER_POS_X { SB = 373, BB = 213, UTG = 320, MP = 700, CO = 834, BTN = 661 };
        public enum DEALER_POS_Y { SB = 245, BB = 230, UTG = 140, MP = 150, CO = 263, BTN = 299 };

        private int FNbJoueurs;
        private CPartie FPartie; // Pointeur vers un objet de type CPartie qui représente la partie actuelle.
        private CultureInfo FLangage;
        private DEALER_POS_X FDealerPosX;
        private DEALER_POS_Y FDealerPosY;

        private frmJeu()
        /*
            Objectif: Constructeur de la classe par défaut. On ne devrait pas utiliser celui-ci.
        */
        {
            InitializeComponent();
        }

        public frmJeu(CPartie _pPartie)
        /*
            Objectif: Constructeur de la classe qu'on doit utiliser. Initialise les données membres par défaut.
        */
        {
            FPartie = _pPartie;
            FNbJoueurs = 0;
            FDealerPosX = DEALER_POS_X.BTN;
            FDealerPosY = DEALER_POS_Y.BTN;
            FLangage = new CultureInfo("en-CA");
           
            InitializeComponent();

            picDealer.Image = CImageHelper.ScaleImage((Properties.Resources.ResourceManager.GetObject("dealer") as Image), picDealer.Width, picDealer.Height);
        }

        private void txtNbJeton_KeyPress(object sender, KeyPressEventArgs e)
        /*
            Évènement qui se déclenche lorsque l'utilisateur tape le nombre de jetons qu'il veut. On lui permet d'entrer que des chiffres.
        */
        {
            e.Handled = !(e.KeyChar == 8 || (e.KeyChar == ',' && !txtNbJetons.Text.Contains('.')) || (e.KeyChar == '.' && !txtNbJetons.Text.Contains('.')) || (e.KeyChar >= '0' && e.KeyChar <= '9'));
            txtNbJetons.Text = txtNbJetons.Text.Replace(',', '.');

            if (txtNbJetons.Text.Length > 0)
                txtNbJetons.SelectionStart = txtNbJetons.Text.Length;
        }

        private void ChangerJoueurJeton(int _indJoueur, int _iNbJeton)
        /*
            Objectif: Changer le nombre de jetons apparant pour un joueur spécifique.
        */
        {
            // Changer le label correspondant au nombre de jetons d'un joueur spécifique.
            ((Label)Controls.Find("Joueur" + Convert.ToString(_indJoueur), true)[0]).Text = Convert.ToString(_iNbJeton);
        }

        private void ChangerPot(int _NbJetons)
        /*
            Objectif: Changer le pot.
        */
        {
            txtNbJetons.Text = Convert.ToString(_NbJetons);
        }

        public void MettreAJourChoixDuJoueur(bool _peutFolder, bool _peutCheck, bool _peutCall, bool _peutBet, bool _peutRaise, double _nbJetons)
        /*
            Objectif: Selon la phase qu'on est rendu, permettre au joueur de faire son choix.
        */
        {
            btnFold.Enabled = btnFold.Visible = _peutFolder;
            btnCheck.Enabled = btnCheck.Visible = _peutCheck;
            btnCall.Enabled = btnCall.Visible = _peutCall;


            btnBet.Enabled = btnBet.Visible = btnHalfPot.Enabled = btnHalfPot.Visible = btnTwoThirdPot.Enabled =
            btnTwoThirdPot.Visible = btnPot.Enabled = btnPot.Visible = btnMax.Enabled = btnMax.Visible =
            txtNbJetons.Enabled = txtNbJetons.Visible = _peutBet;

            if (_peutRaise)
            {
                txtNbJetons.Enabled = txtNbJetons.Visible = btnRaise.Enabled = btnRaise.Visible = btnMax.Enabled = btnMax.Visible = true;

                if (_nbJetons < (FPartie.PDerniereMise + FPartie.PBigBlind))
                    txtNbJetons.Text = Convert.ToString(Math.Round(_nbJetons, 2).ToString("#0.00", FLangage));
                else
                    txtNbJetons.Text = Convert.ToString(Math.Round((FPartie.PDerniereMise + FPartie.PBigBlind), 2).ToString("#0.00", FLangage));
            }
            else
                btnRaise.Enabled = btnRaise.Visible = false;
        }

        private void btnCall_Click(object sender, EventArgs e)
        /*
            Évènement qui se déclenche lorsqu'on appuie sur le bouton CALL. Envoyer le choix au serveur.
        */
        {
            btnCall.Focus();
            FPartie.Call();
        }

        private void btnRaise_Click(object sender, EventArgs e)
         /*
            Évènement qui se déclenche lorsqu'on appuie sur le bouton RAISE. Envoyer le choix au serveur.
        */
        {
            btnRaise.Focus();
            FPartie.Raise(float.Parse(txtNbJetons.Text));
        }

        private void btnFold_Click(object sender, EventArgs e)
        /*
            Évènement qui se déclenche lorsqu'on appuie sur le bouton FOLD. Envoyer le choix au serveur.
        */
        {
            btnFold.Focus();
            FPartie.Fold();
        }

        private void btnCheck_Click(object sender, EventArgs e)
        /*
            Évènement qui se déclenche lorsqu'on appuie sur le bouton CHECK. Envoyer le choix au serveur.
        */
        {
            btnCheck.Focus();
            FPartie.Check();     
        }

        public void AfficherFlop(string _Carte1, string _Carte2, string _Carte3)
        {
            PictureBox CarteActuel = null;
            Image ImgAInserer = null;

            picBoardCarte1.Enabled = picBoardCarte1.Visible = true;
            picBoardCarte2.Enabled = picBoardCarte2.Visible = true;
            picBoardCarte3.Enabled = picBoardCarte3.Visible = true;

            for (int IndCarte = 1; IndCarte <= 3; IndCarte++)
            {
                CarteActuel = (Controls.Find("picBoardCarte" + Convert.ToString(IndCarte), false)[0] as PictureBox);

                switch (IndCarte)
                {
                    case 1:
                        ImgAInserer = (Properties.Resources.ResourceManager.GetObject("_" + _Carte1) as Image);
                        break;
                    case 2:
                        ImgAInserer = (Properties.Resources.ResourceManager.GetObject("_" + _Carte2) as Image);
                        break;
                    case 3:
                        ImgAInserer = (Properties.Resources.ResourceManager.GetObject("_" + _Carte3) as Image);
                        break;
                }

                CarteActuel.Image = CImageHelper.ScaleImage(ImgAInserer, CarteActuel.Width, CarteActuel.Height);
            }

            CarteActuel = null;
            ImgAInserer = null;
        }

        public void AfficherTurn(string _Carte)
        {
            Image ImgAInserer = (Properties.Resources.ResourceManager.GetObject("_" + _Carte) as Image);

            picBoardCarte4.Enabled = picBoardCarte4.Visible = true;
            picBoardCarte4.Image = CImageHelper.ScaleImage(ImgAInserer, picBoardCarte4.Width, picBoardCarte5.Height);
        }

        public void AfficherRiver(string _Carte)
        {
            Image ImgAInserer = (Properties.Resources.ResourceManager.GetObject("_" + _Carte) as Image);

            picBoardCarte5.Enabled = picBoardCarte5.Visible = true;
            picBoardCarte5.Image = CImageHelper.ScaleImage(ImgAInserer, picBoardCarte5.Width, picBoardCarte5.Height);
        }

        public void AfficherCartes(int _IndJoueur, string _Cartes)
        /*
            Objectif: Afficher les cartes selon les cartes reçu en paramètre.
        */
        {
            PictureBox CarteActuel1 = (Controls.Find("picCarte" + Convert.ToString(_IndJoueur + 1) + '1', false)[0] as PictureBox);
            PictureBox CarteActuel2 = (Controls.Find("picCarte" + Convert.ToString(_IndJoueur + 1) + '2', false)[0] as PictureBox);

            Image ImgAInserer1 = (Properties.Resources.ResourceManager.GetObject("_" + _Cartes.Split(' ')[0]) as Image);
            Image ImgAInserer2 = (Properties.Resources.ResourceManager.GetObject("_" + _Cartes.Split(' ')[1]) as Image);

            CarteActuel1.Image = CImageHelper.ScaleImage(ImgAInserer1, CarteActuel1.Width, CarteActuel1.Height);
            CarteActuel1.Enabled = CarteActuel1.Visible = true;

            CarteActuel2.Image = CImageHelper.ScaleImage(ImgAInserer2, CarteActuel2.Width, CarteActuel2.Height);
            CarteActuel2.Enabled = CarteActuel2.Visible = true;
        }

        public void AfficherCartesCachee(int _IndJoueur)
        {
            PictureBox carteActuel1 = (Controls.Find("picCarte" + Convert.ToString(_IndJoueur + 1) + '1', false)[0] as PictureBox);
            PictureBox carteActuel2 = (Controls.Find("picCarte" + Convert.ToString(_IndJoueur + 1) + '2', false)[0] as PictureBox);

            Image imgAInserer = (Properties.Resources.ResourceManager.GetObject("back2") as Image);

            carteActuel1.Enabled = carteActuel1.Visible = true;
            carteActuel2.Enabled = carteActuel2.Visible = true;

            carteActuel1.Image = CImageHelper.ScaleImage(imgAInserer, carteActuel1.Width, carteActuel1.Height);
            carteActuel2.Image = CImageHelper.ScaleImage(imgAInserer, carteActuel2.Width, carteActuel2.Height);
        }

        public void CacherCartes(int _IndJoueur)
        {
            PictureBox CarteActuel1 = (Controls.Find("picCarte" + Convert.ToString(_IndJoueur + 1) + '1', false)[0] as PictureBox);
            PictureBox CarteActuel2 = (Controls.Find("picCarte" + Convert.ToString(_IndJoueur + 1) + '2', false)[0] as PictureBox);
           
            CarteActuel1.Enabled = CarteActuel1.Visible = false;
            CarteActuel2.Enabled = CarteActuel2.Visible = false;
        }

        public void ResetActions(bool _ResetBoard)
        {
            for (int IndLabel = 1; IndLabel <= 6; IndLabel++)
                (Controls.Find("lblChoix" + Convert.ToString(IndLabel), false)[0] as Label).ResetText();

            if (_ResetBoard)
            {
                picBoardCarte1.Enabled = picBoardCarte1.Visible = false;
                picBoardCarte2.Enabled = picBoardCarte2.Visible = false;
                picBoardCarte3.Enabled = picBoardCarte3.Visible = false;
                picBoardCarte4.Enabled = picBoardCarte4.Visible = false;
                picBoardCarte5.Enabled = picBoardCarte5.Visible = false;

                picBoardCarte1.Image = null;
                picBoardCarte2.Image = null;
                picBoardCarte3.Image = null;
                picBoardCarte4.Image = null;
                picBoardCarte5.Image = null;
            }
        }

        public void AfficherGagnerPotDunJoueur(int _IndJoueur, float _Pot)
        {
            ((Label)Controls.Find("lblChoix" + Convert.ToString((_IndJoueur + 1)), true)[0]).Text = "A REMPORTÉ " + Convert.ToString(Math.Round(_Pot, 2)) + "$";
        }

        public void AfficherCheckDunJoueur(int _indJoueur)
        /*
            Objectif: Afficher qu'un joueur a check.
        */
        {
            ((Label)Controls.Find("lblChoix" + Convert.ToString((_indJoueur + 1)), true)[0]).Text = "CHECK";
        }

        public void AfficherCallDunJoueur(int _indJoueur)
        /*
            Objectif: Afficher qu'un joueur a call.
        */
        {
            ((Label)Controls.Find("lblChoix" + Convert.ToString((_indJoueur + 1)), true)[0]).Text = "CALL " + Math.Round(FPartie.PDerniereMise, 2).ToString("#0.00", FLangage) + "$";       
            lblPot.Text = "Pot: " + Math.Round(FPartie.PPot, 2).ToString("#0.00", FLangage) + '$';
        }

        public void AfficherMiseDunJoueur(int _indJoueur)
        /*
            Objectif: Afficher qu'un joueur a misé.
        */
        {
            ((Label)Controls.Find("lblChoix" + Convert.ToString((_indJoueur + 1)), true)[0]).Text = "MISE " + Math.Round(FPartie.PDerniereMise, 2).ToString("#0.00", FLangage) + "$";
            lblPot.Text = "Pot: " + Math.Round(FPartie.PPot, 2).ToString("#0.00", FLangage) + '$';
        }

        public void AfficherRaiseDunJoueur(int _indJoueur)
        /*
            Objectif: Afficher qu'un joueur a raise.
        */
        {
            ((Label)Controls.Find("lblChoix" + Convert.ToString((_indJoueur + 1)), true)[0]).Text = "RAISE " + Math.Round(FPartie.PDerniereMise, 2).ToString("#0.00", FLangage) + "$";
            lblPot.Text = "Pot: " + Math.Round(FPartie.PPot, 2).ToString("#0.00", FLangage) + '$';
        }

        public void AfficherPot()
        {
            lblPot.Text = "Pot: " + (Math.Round(FPartie.PPot, 2)).ToString("#0.00", FLangage) + '$';
        }

        public void AfficherJoueurs(int _IndDebut, int _IndFin)
        /*
            Objectif: Afficher les joueurs dans la partie.
        */
        {
            int IndActuel = 1;

            FNbJoueurs = (_IndFin - _IndDebut) + 1;

            while (IndActuel <= 6)
            {
                Controls.Find("lblJoueur" + IndActuel, true)[0].Enabled = (IndActuel >= _IndDebut && IndActuel <= _IndFin);
                Controls.Find("lblJoueur" + IndActuel, true)[0].Visible = (IndActuel >= _IndDebut && IndActuel <= _IndFin);

                Controls.Find("lblJoueur" + IndActuel + "jeton", true)[0].Enabled = (IndActuel >= _IndDebut && IndActuel <= _IndFin);
                Controls.Find("lblJoueur" + IndActuel + "jeton", true)[0].Visible = (IndActuel >= _IndDebut && IndActuel <= _IndFin);

                Controls.Find("lblChoix" + IndActuel, true)[0].Enabled = (IndActuel >= _IndDebut && IndActuel <= _IndFin);
                Controls.Find("lblChoix" + IndActuel, true)[0].Visible = (IndActuel >= _IndDebut && IndActuel <= _IndFin);

                Controls.Find("picNoir" + IndActuel, true)[0].Enabled = (IndActuel >= _IndDebut && IndActuel <= _IndFin);
                Controls.Find("picNoir" + IndActuel, true)[0].Visible = (IndActuel >= _IndDebut && IndActuel <= _IndFin);
                IndActuel++;
            }

        }

        public void AfficherNbJetonDunJoueur(int _indJoueur) 
        {
            ((Label)Controls.Find("lblJoueur" + Convert.ToString(_indJoueur + 1) + "Jeton", true)[0]).Text = (Math.Round(FPartie.RetournerNbJetonPourUnJoueur(_indJoueur), 2).ToString("#.00", FLangage) + "$");
        }

        private void btnBet_Click(object sender, EventArgs e) 
        /*
            Évènement qui se produit lorsqu'on clic sur le bouton pour miser.
        */
        {
            if (txtNbJetons.Text == "")
                txtNbJetons.Text = Convert.ToString(FPartie.PBigBlind);

            FPartie.Bet(float.Parse(txtNbJetons.Text, FLangage));
        }

        private void btnHalfPot_Click(object sender, EventArgs e) 
        /*
            Évènement qui se produit lorsqu'on clic sur le bouton "1/2 pot".
        */
        {
            txtNbJetons.Text = (Math.Round(Math.Round(FPartie.PPot, 2) * 0.5, 2)).ToString("#0.00", FLangage);
        }

        private void btnTwoThirdPot_Click(object sender, EventArgs e)
        /*
            Évènement qui se produit lorsqu'on clic sur le bouton "2/3 pot".
        */
        {
            txtNbJetons.Text = (Math.Round(Math.Round(FPartie.PPot, 2) * (2.0 / 3.0), 2)).ToString("#0.00", FLangage);
        }

        private void btnPot_Click(object sender, EventArgs e)
        /*
            Évènement qui se produit lorsqu'on clic sur le bouton "pot".
        */
        {
            txtNbJetons.Text = (Math.Round(FPartie.PPot, 2)).ToString("#0.00", FLangage);
        }

        private void btnMax_Click(object sender, EventArgs e) {
        /*
            Évènement qui se produit lorsqu'on clic sur le bouton "max".
        */
            txtNbJetons.Text = (FPartie.RetournerNbJetonPourUnJoueur(FPartie.PIndJoueurActuel)).ToString("#0.00", FLangage);
        }

        private void txtNbJeton_Leave(object sender, EventArgs e) {
        /*
            Évènement qui se produit lorsque le focus sort de la boîte de texte correspondante aux jetons.
        */
            float NbJetons = 0;

            if (float.TryParse(txtNbJetons.Text, out NbJetons))
            {
                if (NbJetons < (FPartie.PDerniereMise + FPartie.PBigBlind))
                    txtNbJetons.Text = Convert.ToString(Math.Round(FPartie.PDerniereMise + FPartie.PBigBlind, 2));
                else if (NbJetons > (FPartie.RetournerNbJetonPourUnJoueur(FPartie.PIndJoueurActuel)))
                    txtNbJetons.Text = Convert.ToString(Math.Round(FPartie.PDerniereMise + FPartie.PBigBlind, 2));
            }
            else
                txtNbJetons.Text = Convert.ToString(Math.Round(FPartie.PDerniereMise + FPartie.PBigBlind, 2));
        }

        private void btnHalfPot_EnabledChanged(object sender, EventArgs e) {
        /*
            Évènement qui se produit lorsque l'état des boutons "1/2, 2/3, pot et max" changent.
        */
            (sender as Button).Visible = txtNbJetons.Visible = (sender as Button).Enabled;
        }

        public void AfficherSmallBlind(int _IndJoueurTour)
        {
            (Controls.Find("lblchoix" + (_IndJoueurTour + 1), false)[0] as Label).Text = "SMALL BLIND: " + Math.Round(FPartie.PSmallBlind, 2).ToString("#0.00", FLangage) + '$';
        }

        public void AfficherBigBlind(int _IndJoueurTour)
        {
            (Controls.Find("lblchoix" + (_IndJoueurTour + 1), false)[0] as Label).Text = "BIG BLIND: " + Math.Round(FPartie.PBigBlind, 2).ToString("#0.00", FLangage) + '$';
        }

        public void PositionnerDealer(DEALER_POS _dealerPosition)
        {
            switch (_dealerPosition)
            {
                case DEALER_POS.SB:
                    FDealerPosX = DEALER_POS_X.SB;
                    FDealerPosY = DEALER_POS_Y.SB;
                    break;
                case DEALER_POS.BB:
                    FDealerPosX = DEALER_POS_X.BB;
                    FDealerPosY = DEALER_POS_Y.BB;
                    break;
                case DEALER_POS.UTG:
                    FDealerPosX = DEALER_POS_X.UTG;
                    FDealerPosY = DEALER_POS_Y.UTG;
                    break;
                case DEALER_POS.MP:
                    FDealerPosX = DEALER_POS_X.MP;
                    FDealerPosY = DEALER_POS_Y.MP;
                    break;
                case DEALER_POS.CO:
                    FDealerPosX = DEALER_POS_X.CO;
                    FDealerPosY = DEALER_POS_Y.CO;
                    break;
                case DEALER_POS.BTN:
                    FDealerPosX = DEALER_POS_X.BTN;
                    FDealerPosY = DEALER_POS_Y.BTN;
                    break;
            }

            if (FNbJoueurs == 2 && _dealerPosition == DEALER_POS.BB)
            {
                FDealerPosX = FDealerPosX + 20;
                FDealerPosY = FDealerPosY + 30;
            }                               

            picDealer.Location = new Point((int)FDealerPosX, (int)FDealerPosY);
        }

        public DEALER_POS_X RetournerPosDealerX()
        {
            return (DEALER_POS_X)picDealer.Location.X;
        }

        public DEALER_POS_Y RetournerPosDealerY()
        {
            return (DEALER_POS_Y)picDealer.Location.Y;
        }


    }
}
