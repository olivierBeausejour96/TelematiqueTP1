﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using static TP.CPartie;

namespace TP
{
    public class CTableInfosNLHE2Max : CTableInfos
    {
        #region Données membres, accesseurs, constantes et énumérés
        private CJoueur FFVillain;
        /// <summary>
        /// Joueur adversaire de la table en cours.
        /// </summary>
        public CJoueur PVillain
        {
            get { return FFVillain; }
            set
            {
                FFVillain = value;

                if (FFVillain != null)
                {
                    Reset();
                    AjouterJoueurDansFFLstActionsMainsActuel(FFVillain);
                }
            }
        }
        
        /// <summary>
        /// Historique des actions de la main actuel en train de se jouer.
        /// Clé: Joueur que l'on souhaite voir ses historiques d'action.
        ///      Exemple: On veut voir les actions du BTN, on prend le pointeur du BTN et on accède à ses actions selon le stade de tour (preflop, flop, turn ou river).
        /// </summary>
        private Dictionary<CJoueur, List<CAction>[]> FFLstActionsMainActuel;
        #endregion
        #region Constructeurs
        public CTableInfosNLHE2Max(double _smallBlind, double _bigBlind, double _antes, double _posX, double _posY) : base(_smallBlind, _bigBlind, _antes, _posX, _posY)
        {
            FFLstActionsMainActuel = new Dictionary<CJoueur, List<CAction>[]>();
        }
        
        public CTableInfosNLHE2Max(double _smallBlind, double _bigBlind, double _antes, double _posX, double _posY, CJoueur _villain) : base(_smallBlind, _bigBlind, _antes, _posX, _posY)
        {
            if (_villain == null)
                throw new ArgumentNullException();

            FFVillain = _villain;
            FFLstActionsMainActuel = new Dictionary<CJoueur, List<CAction>[]>();

            AjouterJoueurDansFFLstActionsMainsActuel(FFVillain);
        }
        #endregion
        
        /// <summary>
        /// Ajoute un joueur dans la liste de tous les actions d'une main X. (FFLstActionsMainsActuel).
        /// Si le joueur est déjà présent, il ne fera rien.
        /// </summary>
        /// <param name="_joueur">Joueur à ajouter.</param>
        private void AjouterJoueurDansFFLstActionsMainsActuel(CJoueur _joueur)
        {
            // Si le joueur n'existe pas dans la liste, on l'ajoute
            if (FFLstActionsMainActuel.ContainsKey(_joueur))
            {
                FFLstActionsMainActuel.Add(_joueur, new List<CAction>[CNB_STREETS]);

                FFLstActionsMainActuel[_joueur][(int)ToursPossible.Preflop] = new List<CAction>();
                FFLstActionsMainActuel[_joueur][(int)ToursPossible.Flop] = new List<CAction>();
                FFLstActionsMainActuel[_joueur][(int)ToursPossible.Turn] = new List<CAction>();
                FFLstActionsMainActuel[_joueur][(int)ToursPossible.River] = new List<CAction>();
            }
        }
        /// <summary>
        /// Ajouter une action dans l'historique des actions par joueur.
        /// </summary>
        /// <param name="_joueur">Joueur qui a fait l'action.</param>
        /// <param name="_action">Action du joueur.</param>
        /// <param name="_tour">Stade de la main actuel (preflop, flop, turn ou river)</param>
        public void AjouterAction(CJoueur _joueur, CAction _action, ToursPossible _tour)
        {
            if (!FFLstActionsMainActuel.ContainsKey(_joueur))
                throw new ArgumentException("Le joueur n'existe pas dans la liste d'historique d'action par joueur.");

            FFLstActionsMainActuel[_joueur][(int)_tour].Add(_action);
        }

        /// <summary>
        /// Réinitialiser les informations de la main actuel 
        /// (s'il y a une main en train de se jouer, cette procédure supprime l'historique de cette main)
        /// </summary>
        public void Reset()
        {
            FFLstActionsMainActuel[FFVillain][(int)ToursPossible.Preflop].Clear();
            FFLstActionsMainActuel[FFVillain][(int)ToursPossible.Flop].Clear();
            FFLstActionsMainActuel[FFVillain][(int)ToursPossible.Turn].Clear();
            FFLstActionsMainActuel[FFVillain][(int)ToursPossible.River].Clear();
        }

        public override ToursPossible getTourActuel()
        {
            throw new NotImplementedException();
        }

        public override TypesPot getTypePot()
        {
            throw new NotImplementedException();
        }
    }
}
