﻿using System;
using System.Collections.Generic;
using static TP.CAction;
using static TP.CPartie;

namespace TP
{
    public sealed class CBotPoker : CJoueur
    {
        /// <summary>
        /// Range du bot au moment de la main actuel (pour être balanced). Sera utilisé pour prendre des décisions.
        /// </summary>
        List<CCarte> FFLstRange;

        public CBotPoker(double _nbJetons) : base(_nbJetons)
        {            
        }

        public CAction PrendreDecision(CTableInfosNLHE2Max _headsUpTable)
        {
            try
            {
                switch (_headsUpTable.getTourActuel())
                {
                    case ToursPossible.Preflop:
                        switch (_headsUpTable.getTypePot())
                        {
                            case TypesPot.OneBet:
                                break;
                            case TypesPot.TwoBet:
                                break;
                            case TypesPot.ThreeBet:
                                break;
                            case TypesPot.FourBet:
                                break;
                            case TypesPot.FiveBetEtPlus:
                                break;
                        }
                        break;
                    case ToursPossible.Flop:
                        return new CAction(ActionsPossible.Check);
                    case ToursPossible.Turn:
                        return new CAction(ActionsPossible.Check);
                    case ToursPossible.River:
                        return new CAction(ActionsPossible.Check);
                }
            }
            catch
            {
                return new CAction(ActionsPossible.Aucune);
            }
            return new CAction(ActionsPossible.Check);
        }

        internal CAction PrendreDecision()
        {
            throw new NotImplementedException();
        }
    }
}
