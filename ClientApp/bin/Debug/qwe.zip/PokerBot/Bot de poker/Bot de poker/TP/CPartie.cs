﻿using System;
using System.Collections.Generic;
using System.Linq;

using HoldemHand;
using static TP.CAction;
using System.Threading;

namespace TP
{
    public class CPartie
    {
        #region Données membres, accesseurs, constantes et énumérés
        public enum ToursPossible { Preflop, Flop, Turn, River };
        public enum TypesPot { OneBet, TwoBet, ThreeBet, FourBet, FiveBetEtPlus };

        private const int NBCARTESTOTAL = 52; // Représente le nombre de cartes total dans un "deck" normal.
        /// <summary>
        /// Nombre de "streets" total au poker. (Preflop, Flop, Turn, River)
        /// </summary>
        public const int CNB_STREETS = 4;
        private const int SB = 0;
        private const int BB = 1;
        private const int UTG = 2;
        private const int MP = 3;
        private const int CO = 4;
        private const int DEALER = 5;

        /// <summary>
        /// Indice du dernier joueur (correspondant à FTabJoueurs) à parler au tour actuel (tour étant, soit preflop, flop, turn ou river)
        /// </summary>
        private int FIndDernierJoueurAParler;

        private int FFIndPremierJoueurAParlerPostflop;       
        /// <summary>
        /// Indice du joueur (correspondant à FTabJoueurs) premier à parler postflop
        /// </summary>
        public int PIndPremierJoueurAParlerPostflop
        {
            private set
            {
                if (FFLstJoueursPasFold == null || !FFLstJoueursPasFold.Contains(value))
                    throw new Exception("Valeur invalide. Vérifiez que FLstJoueursPasFold est valide et que la valeur donnée est valide.");

                FFIndPremierJoueurAParlerPostflop = value;
            }
            get { return FFIndPremierJoueurAParlerPostflop; }
        }

        /// <summary>
        /// Indice du joueur (correspondant à FTabJoueurs) premier à parler postflop pour le prochain tour (tour étant, soit preflop, flop turn ou river)
        /// </summary>
        private int FIndPremierJoueurAParlerPostflopProchainTour;

        private int FIndJoueurActuel;        
        /// <summary>
        /// Indice du joueur actuel (correspondant à FTabJoueurs) à qui est le tour de jouer.
        /// </summary>
        public int PIndJoueurActuel
        {
            get { return FIndJoueurActuel; }
        }        

        private double FFNbJetonsDepart;
        /// <summary>
        /// Nombre de jetons au départ si un joueur meurt (plus petit ou égal à 0 jetons) ou lorsqu'on initialise une partie
        /// </summary>
        public double PNbJetonsDepart
        {
            get { return FFNbJetonsDepart; }
        }

        private double FFSmallBlind;
        /// <summary>
        /// Small blind pour chaque main.
        /// </summary>
        public double PSmallBlind
        {
            get { return FFSmallBlind; }
        }

        private double FFBigBlind;
        /// <summary>
        /// Big blind pour chaque main.
        /// </summary>
        public double PBigBlind
        {
            get { return FFBigBlind; }
        }

        private double FFAntes;
        /// <summary>
        /// Antes pour chaque main.
        /// </summary>
        public double PAntes
        {
            get { return FFAntes; }
        }

        private double FFPot;
        /// <summary>
        /// Pot de la main actuel.
        /// </summary>
        public double PPot
        {
            get { return FFPot; }
        }

        private double FFDerniereMise;
        /// <summary>
        /// Dernière mise du dernier joueur ayant "bet" ou "raise" au cours d'une main.
        /// </summary>
        public double PDerniereMise
        {
            get { return FFDerniereMise; }
        }

        /// <summary>
        /// Représente les cartes des joueurs. L'indice est l'indice des joueurs.
        /// </summary>
        private string[] FFTabJoueursCartes;

        private ToursPossible FFStadeMain;
        /// <summary>
        /// Stade de la main actuel (preflop, flop, turn ou river)
        /// </summary>
        public ToursPossible PStadeMain
        {
            private set
            {
                if (!Enum.IsDefined(typeof(ToursPossible), value))
                    throw new ArgumentException();

                FFStadeMain = value;
            }
            get { return FFStadeMain; }
        }

        /// <summary>
        /// Tous les joueurs de la partie
        /// </summary>
        private CJoueur[] FFTabJoueurs;

        /// <summary>
        /// Contient les indices des joueurs qui n'ont pas encore couché leur carte au tour présent.
        /// </summary>
        private List<int> FFLstJoueursPasFold;
        /// <summary>
        /// Cartes dans le paquet de carte
        /// </summary>
        private List<CCarte> FFLstCartes;

        /// <summary>
        /// Liste d'actions de la main actuel
        /// </summary>
        private Dictionary<CJoueur, List<CAction>[]> FFLstActionsMainActuel;

        /// <summary>
        /// Liste d'actions possibles que le joueur à qui est le tour de jouer peut faire.
        /// </summary>
        private HashSet<ActionsPossible> FLstActionsPossibleJoueurActuel;

        /// <summary>
        /// Interface reliée à la partie.
        /// </summary>
        private frmJeu FFrmJeu;

        /// <summary>
        /// Represente le board en string
        /// note: les 3 premieres carte sont le flop
        /// note2: la quatrieme carte est la turn
        /// note3: la cinquieme carte est la river
        /// appendice: s'il existe plus que 5 cartes c'est pas normal
        /// </summary>
        private string FFBoard;

        /// <summary>
        /// Retourner le nombre de jetons pour un joueur spécifique dans une main actuel.
        /// </summary>
        /// <param name="_indJoueur">Indice du joueur que l'on souhaite retourner ses jetons.</param>
        /// <returns>Retourne le nombre de jetons du joueur correspond à _indJoueur.</returns>
        public double RetournerNbJetonPourUnJoueur(int _indJoueur)
        {
            if (_indJoueur < 0 || FFTabJoueurs == null || _indJoueur >= FFTabJoueurs.Length)
                throw new InvalidOperationException("L'indice de joueur reçu est invalide.");

            return FFTabJoueurs[_indJoueur].PNbJetons;
        }
        /// <summary>
        /// Retourner une carte.
        /// </summary>
        /// <param name="_indJoueur">Indice du joueur que l'on souhaite retourner sa carte.</param>
        /// <param name="_indCarte">Indice de la carte (1, 2 seulement possible)</param>
        /// <returns>Retourne la carte.</returns>
        public string RetournerUneCarte(int _indJoueur, int _indCarte)
        {
            if (_indJoueur < 0 || FFTabJoueurs == null || _indJoueur >= FFTabJoueurs.Length ||
                FFTabJoueursCartes == null || FFTabJoueursCartes[_indJoueur] == "")
                throw new InvalidOperationException("L'indice de joueur reçu est invalide.");
            else if (_indCarte < 0 || _indCarte > 1)
                throw new InvalidOperationException("L'indice de la carte reçu est invalide.");

            return FFTabJoueursCartes[_indJoueur].Split(' ')[_indCarte];
        }
        #endregion

        /// <summary>
        /// Constructeur par défaut.
        /// </summary>
        /// <param name="_nbJoueurs">Nombre de joueurs au départ de la partie.</param>
        /// <param name="_nbRobots">Nombre de robots au départ de la partie.</param>
        /// <param name="_nbJetonsDepart">Nombre de jetons pour chaque joueur au départ de la partie.</param>
        /// <param name="_smallBlind">Small bind pour chaque main dans la partie.</param>
        /// <param name="_bigBlind">Big blind pour chaque main dans la partie.</param>
        /// <param name="_antes">Antes pour chaque main de la partie.</param>
        public CPartie(int _nbJoueurs, int _nbRobots, double _nbJetonsDepart, double _smallBlind, double _bigBlind, double _antes)
        {
            #region Méthodes
            Action InitialiserJoueurs = () =>
            {
                int nbRobotInitialise = 0;

                for (int indTab = 0; indTab < _nbJoueurs; indTab++)
                {
                    if (nbRobotInitialise != _nbRobots)
                    {
                        CBotPoker nouveauBot = new CBotPoker(_nbJetonsDepart);
                                                
                        FFTabJoueurs[indTab] = nouveauBot;
                        FFLstActionsMainActuel[nouveauBot] = new List<CAction>[CNB_STREETS];
                        FFLstActionsMainActuel[nouveauBot][(int)ToursPossible.Preflop] = new List<CAction>();
                        FFLstActionsMainActuel[nouveauBot][(int)ToursPossible.Flop] = new List<CAction>();
                        FFLstActionsMainActuel[nouveauBot][(int)ToursPossible.Turn] = new List<CAction>();
                        FFLstActionsMainActuel[nouveauBot][(int)ToursPossible.River] = new List<CAction>();

                        ++nbRobotInitialise;
                    }
                    else
                    {
                        CJoueur nouveauJoueur = new CJoueur(_nbJetonsDepart);

                        FFTabJoueurs[indTab] = nouveauJoueur;

                        FFLstActionsMainActuel[nouveauJoueur] = new List<CAction>[CNB_STREETS];
                        FFLstActionsMainActuel[nouveauJoueur][(int)ToursPossible.Preflop] = new List<CAction>();
                        FFLstActionsMainActuel[nouveauJoueur][(int)ToursPossible.Flop] = new List<CAction>();
                        FFLstActionsMainActuel[nouveauJoueur][(int)ToursPossible.Turn] = new List<CAction>();
                        FFLstActionsMainActuel[nouveauJoueur][(int)ToursPossible.River] = new List<CAction>();
                    }                   
                }
            };
            #endregion
            // Création du tableau des cartes des joueurs
            FFTabJoueursCartes = new string[_nbJoueurs];

            #region Création de la liste des cartes
            FFLstCartes = new List<CCarte>();

            FFLstCartes.Add(new CCarte(CCarte.Valeur.Ace, CCarte.Type.Spades));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Ace, CCarte.Type.Hearts));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Ace, CCarte.Type.Diamonds));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Ace, CCarte.Type.Clubs));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Two, CCarte.Type.Spades));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Two, CCarte.Type.Hearts));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Two, CCarte.Type.Diamonds));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Two, CCarte.Type.Clubs));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Three, CCarte.Type.Spades));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Three, CCarte.Type.Hearts));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Three, CCarte.Type.Diamonds));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Three, CCarte.Type.Clubs));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Four, CCarte.Type.Spades));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Four, CCarte.Type.Hearts));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Four, CCarte.Type.Diamonds));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Four, CCarte.Type.Clubs));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Five, CCarte.Type.Spades));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Five, CCarte.Type.Hearts));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Five, CCarte.Type.Diamonds));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Five, CCarte.Type.Clubs));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Six, CCarte.Type.Spades));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Six, CCarte.Type.Hearts));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Six, CCarte.Type.Diamonds));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Six, CCarte.Type.Clubs));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Seven, CCarte.Type.Spades));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Seven, CCarte.Type.Hearts));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Seven, CCarte.Type.Diamonds));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Seven, CCarte.Type.Clubs));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Eight, CCarte.Type.Spades));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Eight, CCarte.Type.Hearts));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Eight, CCarte.Type.Diamonds));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Eight, CCarte.Type.Clubs));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Nine, CCarte.Type.Spades));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Nine, CCarte.Type.Hearts));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Nine, CCarte.Type.Diamonds));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Nine, CCarte.Type.Clubs));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Ten, CCarte.Type.Spades));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Ten, CCarte.Type.Hearts));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Ten, CCarte.Type.Diamonds));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Ten, CCarte.Type.Clubs));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Jack, CCarte.Type.Spades));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Jack, CCarte.Type.Hearts));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Jack, CCarte.Type.Diamonds));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Jack, CCarte.Type.Clubs));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Queen, CCarte.Type.Spades));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Queen, CCarte.Type.Hearts));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Queen, CCarte.Type.Diamonds));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Queen, CCarte.Type.Clubs));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.King, CCarte.Type.Spades));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.King, CCarte.Type.Hearts));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.King, CCarte.Type.Diamonds));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.King, CCarte.Type.Clubs));
            #endregion
            // Création de la liste des joueurs qui n'ont pas foldé au cours d'un tour
            FFLstJoueursPasFold = new List<int>();

            // Création des joueurs
            FFTabJoueurs = new CJoueur[_nbJoueurs];
            FFLstActionsMainActuel = new Dictionary<CJoueur, List<CAction>[]>();
            FLstActionsPossibleJoueurActuel = new HashSet<ActionsPossible>();

            // Initialisation des paramètres de la partie.
            FFSmallBlind = _smallBlind;
            FFBigBlind = _bigBlind;
            FFAntes = _antes;
            FFNbJetonsDepart = _nbJetonsDepart;

            FIndJoueurActuel = -1;
            FFIndPremierJoueurAParlerPostflop = -1;
            FIndPremierJoueurAParlerPostflopProchainTour = -1;
            FIndDernierJoueurAParler = -1;                        

            // Initialiser les jetons, etc.
            InitialiserJoueurs();

            // Création et affichage du jeu.
            FFrmJeu = new frmJeu(this);
            // Afficher le nombre de joueurs correspondant.
            FFrmJeu.AfficherJoueurs(1, _nbJoueurs);
            FFrmJeu.Show();

            // Début du premier tour.
            Jouer();
        }

        #region Méthodes principales
        /// <summary>
        /// Jouer une main (se répète à l'infini).
        /// </summary>
        public void Jouer()
        {
            int indPremierJoueurAParlerPreflop = 0;

            #region Méthodes
            Action SelectionnerPremierJoueurAJouerPostflop = () =>
            {
                // S'il n'y a aucun joueur à parler postflop de sélectionné
                if (FFIndPremierJoueurAParlerPostflop == -1)
                {
                    if (FFTabJoueurs.Length == 2)
                        FFIndPremierJoueurAParlerPostflop = FFLstJoueursPasFold.Last(); // Sélectionne le BB automatiquement
                    else
                        FFIndPremierJoueurAParlerPostflop = FFLstJoueursPasFold.First();

                    FIndPremierJoueurAParlerPostflopProchainTour = FFLstJoueursPasFold.ElemNextOf(FFIndPremierJoueurAParlerPostflop);
                }
                else
                {
                    FFIndPremierJoueurAParlerPostflop = FIndPremierJoueurAParlerPostflopProchainTour;
                    FIndPremierJoueurAParlerPostflopProchainTour = FFLstJoueursPasFold.ElemNextOf(FFIndPremierJoueurAParlerPostflop);
                }
            };
            Action SelectionnerPremierJoueurAJouerPreflop = () =>
            {
                if (!FFLstJoueursPasFold.Contains(FFIndPremierJoueurAParlerPostflop))
                    throw new InvalidOperationException("Vous devez affecter une donnée valide à la donnée membre FIndPremierJoueurPostflop");

                // 2 positions après le small blind c'est le premier joueur à parler preflop pour > 2 joueurs.
                if (FFTabJoueurs.Length > 2)
                    indPremierJoueurAParlerPreflop = CListHelper.ElemNextOf(FFLstJoueursPasFold,
                                                                             CListHelper.ElemNextOf(FFLstJoueursPasFold,
                                                                                                    FFIndPremierJoueurAParlerPostflop));
                else
                    indPremierJoueurAParlerPreflop = CListHelper.ElemNextOf(FFLstJoueursPasFold, FFIndPremierJoueurAParlerPostflop);
            };
            Action SelectionnerDernierJoueurAJouerSelonFLstJoueursPasFold = () =>
            {
                if (!FFLstJoueursPasFold.Contains(FFIndPremierJoueurAParlerPostflop))
                    throw new InvalidOperationException("Vous devez affecter une donnée valide à la donnée membre FIndPremierJoueurPostflop");

                if (FFTabJoueurs.Length == 2)
                    FIndDernierJoueurAParler = FFIndPremierJoueurAParlerPostflop;
                else
                    FIndDernierJoueurAParler = FFLstJoueursPasFold.ElemNextOf(FFIndPremierJoueurAParlerPostflop);
            };
            Action AjouterSmallBlind = () =>
            {
                if (!FFLstJoueursPasFold.Contains(indPremierJoueurAParlerPreflop) || !FFLstJoueursPasFold.Contains(FFIndPremierJoueurAParlerPostflop))
                    throw new InvalidOperationException("Vous devez affecter une donnée valide à la donnée membre FIndPremierJoueurPostflop et indPremierJoueurAParlerPreflop");

                if (FFTabJoueurs.Length == 2)
                {
                    // Si le joueur a assez de jetons pour mettre le small blind
                    if (FFTabJoueurs[indPremierJoueurAParlerPreflop].PNbJetons >= PSmallBlind)
                    {
                        FFTabJoueurs[indPremierJoueurAParlerPreflop].PDerniereMise = PSmallBlind;
                        FFTabJoueurs[indPremierJoueurAParlerPreflop].PNbJetons = (FFTabJoueurs[indPremierJoueurAParlerPreflop].PNbJetons - PSmallBlind);
                    }
                    else
                    {
                        FFTabJoueurs[indPremierJoueurAParlerPreflop].PDerniereMise = FFTabJoueurs[indPremierJoueurAParlerPreflop].PNbJetons;
                        FFTabJoueurs[indPremierJoueurAParlerPreflop].PNbJetons = 0;
                    }
                }
                else
                {
                    // Si le joueur a assez de jetons pour mettre le small blind
                    if (FFTabJoueurs[FFIndPremierJoueurAParlerPostflop].PNbJetons >= PSmallBlind)
                    {
                        FFTabJoueurs[FFIndPremierJoueurAParlerPostflop].PDerniereMise = PSmallBlind;
                        FFTabJoueurs[FFIndPremierJoueurAParlerPostflop].PNbJetons = (FFTabJoueurs[FFIndPremierJoueurAParlerPostflop].PNbJetons - PSmallBlind);
                    }
                    else
                    {
                        FFTabJoueurs[FFIndPremierJoueurAParlerPostflop].PDerniereMise = FFTabJoueurs[FFIndPremierJoueurAParlerPostflop].PNbJetons;
                        FFTabJoueurs[FFIndPremierJoueurAParlerPostflop].PNbJetons = 0;
                    }
                }
            };
            Action AjouterBigBlind = () =>
            {
                if (!FFLstJoueursPasFold.Contains(FFIndPremierJoueurAParlerPostflop))
                    throw new InvalidOperationException("Vous devez affecter une donnée valide à la donnée membre FIndPremierJoueurPostflop");

                if (FFTabJoueurs.Length == 2)
                {
                    // Si le joueur a assez de jetons pour mettre un big blind
                    if (FFTabJoueurs[FFIndPremierJoueurAParlerPostflop].PNbJetons >= PBigBlind)
                    {
                        FFTabJoueurs[FFIndPremierJoueurAParlerPostflop].PDerniereMise = PBigBlind;
                        FFTabJoueurs[FFIndPremierJoueurAParlerPostflop].PNbJetons = (FFTabJoueurs[FFIndPremierJoueurAParlerPostflop].PNbJetons - PBigBlind);                      
                    }
                    else
                    {
                        FFTabJoueurs[FFIndPremierJoueurAParlerPostflop].PDerniereMise = FFTabJoueurs[FFIndPremierJoueurAParlerPostflop].PNbJetons;
                        FFTabJoueurs[FFIndPremierJoueurAParlerPostflop].PNbJetons = 0;
                    }
                }
                else
                {
                    // Si le joueur a assez de jetons pour mettre un big blind
                    if (FFTabJoueurs[CListHelper.ElemNextOf(FFLstJoueursPasFold, FFIndPremierJoueurAParlerPostflop)].PNbJetons >= PBigBlind)
                    {
                        FFTabJoueurs[CListHelper.ElemNextOf(FFLstJoueursPasFold, FFIndPremierJoueurAParlerPostflop)].PDerniereMise = PBigBlind;
                        FFTabJoueurs[CListHelper.ElemNextOf(FFLstJoueursPasFold, FFIndPremierJoueurAParlerPostflop)].PNbJetons = (FFTabJoueurs[CListHelper.ElemNextOf(FFLstJoueursPasFold, FFIndPremierJoueurAParlerPostflop)].PNbJetons - PBigBlind);
                    }
                    else
                    {
                        FFTabJoueurs[CListHelper.ElemNextOf(FFLstJoueursPasFold, FFIndPremierJoueurAParlerPostflop)].PDerniereMise = FFTabJoueurs[CListHelper.ElemNextOf(FFLstJoueursPasFold, FFIndPremierJoueurAParlerPostflop)].PNbJetons;
                        FFTabJoueurs[CListHelper.ElemNextOf(FFLstJoueursPasFold, FFIndPremierJoueurAParlerPostflop)].PNbJetons = 0;
                    }
                }
                
            };
            #endregion
            
            FFStadeMain = ToursPossible.Preflop;

            // L'ordre est important pour les procédures suivantes
            RendreTousLesJoueursVivantsEtReinitMises();            
            SelectionnerPremierJoueurAJouerPostflop();
            SelectionnerPremierJoueurAJouerPreflop();
            SelectionnerDernierJoueurAJouerSelonFLstJoueursPasFold();
            // Fin de l'ordre important

            FIndJoueurActuel = indPremierJoueurAParlerPreflop;

            #region Ajout des blinds, mise à jour du pot (backend) et de FDerniereMise
            AjouterSmallBlind();
            AjouterBigBlind();

            FFPot += (FFSmallBlind + FFBigBlind);
            FFDerniereMise = FFBigBlind;
            #endregion

            ReinitialiserLstCartes();

            // Distribuer des cartes aux joueurs
            for (int indJoueur = 0; indJoueur < FFTabJoueurs.Length; ++indJoueur)
                DistribuerCartes(indJoueur, 2);

            #region Mise à jour de l'interface graphique (et si le premier joueur est un robot, le robot va prendre sa décision lui-même)
            FFrmJeu.ResetActions(true);
            GUIPositionnerDealer();

            if (FFTabJoueurs.Length == 2)
            {
                FFrmJeu.AfficherSmallBlind(indPremierJoueurAParlerPreflop);
                FFrmJeu.AfficherBigBlind(FFIndPremierJoueurAParlerPostflop);

                FFrmJeu.AfficherNbJetonDunJoueur(indPremierJoueurAParlerPreflop);
                FFrmJeu.AfficherNbJetonDunJoueur(FFIndPremierJoueurAParlerPostflop);
            }
            else
            {
                FFrmJeu.AfficherSmallBlind(FFIndPremierJoueurAParlerPostflop);
                FFrmJeu.AfficherBigBlind(FFLstJoueursPasFold.ElemNextOf(FFIndPremierJoueurAParlerPostflop));

                FFrmJeu.AfficherNbJetonDunJoueur(FFIndPremierJoueurAParlerPostflop);
                FFrmJeu.AfficherNbJetonDunJoueur(FFLstJoueursPasFold.ElemNextOf(FFIndPremierJoueurAParlerPostflop));
            }
            
            // Si le joueur actuel est un robot, on prend sa décision et on la fait "nous-même".
            if (FFTabJoueurs[FIndJoueurActuel] is CBotPoker)
            {
                CAction decision = (FFTabJoueurs[FIndJoueurActuel] as CBotPoker).PrendreDecision();

                switch (decision.PAction)
                {
                    case ActionsPossible.Aucune:
                        //TODO_L: Arrêter le bot.
                        break;
                    case ActionsPossible.Fold:
                        Fold();
                        break;
                    case ActionsPossible.Check:
                        Check();
                        break;
                    case ActionsPossible.Call:
                        Call();
                        break;
                    case ActionsPossible.Bet:
                        Bet(decision.PMise);
                        break;
                    case ActionsPossible.Raise:
                        Raise(decision.PMise);
                        break;
                }
            }
            else
                GUIMettreAJour();
            #endregion
        }
        /// <summary>
        /// Jouer une main (celle-ci se fait rappeler à chaque tour de joueur) (se répète tant et aussi longtemps que Jouer()) se fait appelé
        /// </summary>
        private void JouerTour()
        {
            #region Methodes
            Action SelectionnerPremierJoueurAJouerPostflop = () =>
            {
                if (FFLstJoueursPasFold.Count() <= 0)
                    throw new InvalidOperationException("Il n'y a aucun joueur dans la liste des joueurs qui joue actuellement!");

                FFIndPremierJoueurAParlerPostflop = (int)CListHelper.PremierElemQuiEstPlusGrandOuEgal<int>(FFLstJoueursPasFold.Cast<IComparable<int>>().ToList(), FFIndPremierJoueurAParlerPostflop);
            };
            Action SelectionnerDernierJoueurAJouerPostflop = () =>
            {
                if (!FFLstJoueursPasFold.Contains(FFIndPremierJoueurAParlerPostflop))
                    throw new InvalidOperationException("Vous devez affecter une donnée valide à la donnée membre FIndPremierJoueurPostflop");

                FIndDernierJoueurAParler = CListHelper.ElemPrecedent(FFLstJoueursPasFold, FFIndPremierJoueurAParlerPostflop);
            };
            Action ChangerStadeTour = () =>
            {
                ++FFStadeMain;

                switch (FFStadeMain)
                {
                    case ToursPossible.Flop:
                        string carte1 = DistributerUneCarte().ToString();
                        string carte2 = DistributerUneCarte().ToString();
                        string carte3 = DistributerUneCarte().ToString();
                        FFBoard = carte1 + " " + carte2 + " " + carte3;
                        FFrmJeu.AfficherFlop(carte1, carte2, carte3);
                        break;
                    case ToursPossible.Turn:
                        string carte4 = DistributerUneCarte().ToString();
                        FFBoard += " " + carte4;
                        FFrmJeu.AfficherTurn(carte4);
                        break;
                    case ToursPossible.River:
                        string carte5 = DistributerUneCarte().ToString();
                        FFBoard += " " + carte5;
                        FFrmJeu.AfficherRiver(carte5);
                        break;
                    default:
                        throw new InvalidOperationException("Stade de tour (flop, turn ou river) invalide.");
                }
            };
            #endregion

            if (FFLstJoueursPasFold.Count == 1)
                MainFini();
            else
            {
                // Si on n'est pas à la fin du tour des joueurs
                if ((FFLstJoueursPasFold.Contains(FIndDernierJoueurAParler) && FIndJoueurActuel != FIndDernierJoueurAParler) ||
                    (!FFLstJoueursPasFold.Contains(FIndDernierJoueurAParler) && FIndJoueurActuel != FFLstJoueursPasFold.Last()))
                {
                    FIndJoueurActuel = CListHelper.ElemNextOf(FFLstJoueursPasFold, FIndJoueurActuel);
                    // Si le joueur actuel est un robot, on prend sa décision et on la fait "nous-même".
                    if (FFTabJoueurs[FIndJoueurActuel] is CBotPoker)
                    {
                        CAction decision = (FFTabJoueurs[FIndJoueurActuel] as CBotPoker).PrendreDecision();

                        switch (decision.PAction)
                        {
                            case ActionsPossible.Aucune:
                                break;
                            case ActionsPossible.Fold:
                                Fold();
                                break;
                            case ActionsPossible.Check:
                                Check();
                                break;
                            case ActionsPossible.Call:
                                Call();
                                break;
                            case ActionsPossible.Bet:
                                Bet(decision.PMise);
                                break;
                            case ActionsPossible.Raise:
                                Raise(decision.PMise);
                                break;
                        }
                    }
                }                    
                else
                {
                    for (int indJoueur = 0; indJoueur < FFTabJoueurs.Length; ++indJoueur)
                        FFTabJoueurs[indJoueur].PDerniereMise = 0;

                    FFDerniereMise = 0;
                    
                    SelectionnerPremierJoueurAJouerPostflop();
                    SelectionnerDernierJoueurAJouerPostflop();
                    
                    FIndJoueurActuel = FFIndPremierJoueurAParlerPostflop;

                    if (FFStadeMain == ToursPossible.River)
                    {
                        MainFini();
                    }
                    else
                    {
                        ChangerStadeTour();
                    }
                    

                    FFrmJeu.ResetActions(false);
                }

                GUIMettreAJour();
            }          
        }
        // TODO_M: Finir cette procédure.
        private void MainFini()
        {
            int IndJoueurGagnant = 0;

            Action Showdown = () =>
            {
                for (int i = 0; i < FFLstJoueursPasFold.Count; i++)
                {
                    int ind = FFLstJoueursPasFold[i];
                    FFrmJeu.AfficherCartes(ind, FFTabJoueursCartes[ind]);
                }

                Hand bestHand = new Hand(FFTabJoueursCartes[FFLstJoueursPasFold[0]], FFBoard);
                IndJoueurGagnant = 0;

                for (int i = 1; i < FFLstJoueursPasFold.Count; i++)
                {
                    Hand currentPlayerHand = new Hand(FFTabJoueursCartes[FFLstJoueursPasFold[i]], FFBoard);
                    if (currentPlayerHand > bestHand)
                    {
                        IndJoueurGagnant = i;
                        bestHand = currentPlayerHand;
                    }
                }
            };



            for (int indJoueur = 0; indJoueur < FFTabJoueurs.Length; ++indJoueur)
            {
                FFLstActionsMainActuel[FFTabJoueurs[indJoueur]][(int)ToursPossible.Preflop].Clear();
                FFLstActionsMainActuel[FFTabJoueurs[indJoueur]][(int)ToursPossible.Flop].Clear();
                FFLstActionsMainActuel[FFTabJoueurs[indJoueur]][(int)ToursPossible.Turn].Clear();
                FFLstActionsMainActuel[FFTabJoueurs[indJoueur]][(int)ToursPossible.River].Clear();
            }

            if (FFLstJoueursPasFold.Count == 1)
            {
                IndJoueurGagnant = FFLstJoueursPasFold.First();
            }
            else
            {
                Showdown();
            }

            FFTabJoueurs[IndJoueurGagnant].PNbJetons = FFTabJoueurs[IndJoueurGagnant].PNbJetons + FFPot;
            FFrmJeu.AfficherGagnerPotDunJoueur(IndJoueurGagnant, (float)FFPot);
            FFrmJeu.Refresh();
            FFPot = 0;

            Thread.Sleep(2000);

            // Désactivé jusqu'à temps qu'on implémente le Showdown
            Jouer();
        }
        #endregion

        #region Méthodes pour les joueurs
        private void RendreTousLesJoueursVivantsEtReinitMises()
        {
            FFLstJoueursPasFold.Clear();

            // Tout le monde est vivant.
            for (int indJoueur = 0; indJoueur < FFTabJoueurs.Length; ++indJoueur)
            {
                FFLstJoueursPasFold.Add(indJoueur);
                FFTabJoueurs[indJoueur].PDerniereMise = 0; // Ici est la réinitialisation de la mise

                if (FFTabJoueurs[indJoueur].PNbJetons == 0)
                    FFTabJoueurs[indJoueur].PNbJetons = FFNbJetonsDepart;

                FFrmJeu.AfficherNbJetonDunJoueur(indJoueur);
            }
        }
        private void MettreAJourChoixJoueurTourActuel()
        {
            if (FFLstJoueursPasFold.IndexOf(FIndJoueurActuel) == -1)
                throw new InvalidOperationException("L'indice de joueur actuel ne correspond à aucun joueur qui joue en cours!");

            CJoueur joueurTourActuel = FFTabJoueurs[FIndJoueurActuel];
            CAction derniereAction = null;

            // On prend la dernière action que le joueur actuel a effectué dans le tour actuel (s'il y en a une)
            if (FFLstActionsMainActuel[joueurTourActuel][(int)FFStadeMain].Count > 0)
                derniereAction = FFLstActionsMainActuel[joueurTourActuel][(int)FFStadeMain].Last();
            else
                derniereAction = new CAction(ActionsPossible.Aucune);

            FLstActionsPossibleJoueurActuel.Clear();

            FLstActionsPossibleJoueurActuel.Add(ActionsPossible.Fold);

            if (FFDerniereMise == 0)
            {
                FLstActionsPossibleJoueurActuel.Add(ActionsPossible.Check);

                if (joueurTourActuel.PNbJetons >= FFBigBlind)
                    FLstActionsPossibleJoueurActuel.Add(ActionsPossible.Bet);
            }
            else if (derniereAction.PMise <= FFDerniereMise)
            {
                // Si le joueur a déjà mis une mise (situation qui arrivera probablement jamais) ou est big blind (seule situation qui va arriver probablement)
                if (derniereAction.PMise == FFDerniereMise || FFTabJoueurs[FIndJoueurActuel].PDerniereMise == FFDerniereMise)
                    FLstActionsPossibleJoueurActuel.Add(ActionsPossible.Check);
                else if (joueurTourActuel.PNbJetons >= FFDerniereMise)
                    FLstActionsPossibleJoueurActuel.Add(ActionsPossible.Call);

                if (joueurTourActuel.PNbJetons >= (FFDerniereMise + FFBigBlind))
                    FLstActionsPossibleJoueurActuel.Add(ActionsPossible.Raise);
            }

        }
        #endregion

        #region Méthodes pour les cartes
        /// <summary>
        /// Initialiser une nouvelle liste de 52 cartes pour la liste des cartes du deck actuel.
        /// </summary>
        private void ReinitialiserLstCartes()
        {
            FFLstCartes.Clear();
            #region Création de la liste des cartes
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Ace, CCarte.Type.Spades));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Ace, CCarte.Type.Hearts));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Ace, CCarte.Type.Diamonds));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Ace, CCarte.Type.Clubs));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Two, CCarte.Type.Spades));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Two, CCarte.Type.Hearts));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Two, CCarte.Type.Diamonds));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Two, CCarte.Type.Clubs));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Three, CCarte.Type.Spades));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Three, CCarte.Type.Hearts));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Three, CCarte.Type.Diamonds));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Three, CCarte.Type.Clubs));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Four, CCarte.Type.Spades));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Four, CCarte.Type.Hearts));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Four, CCarte.Type.Diamonds));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Four, CCarte.Type.Clubs));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Five, CCarte.Type.Spades));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Five, CCarte.Type.Hearts));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Five, CCarte.Type.Diamonds));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Five, CCarte.Type.Clubs));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Six, CCarte.Type.Spades));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Six, CCarte.Type.Hearts));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Six, CCarte.Type.Diamonds));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Six, CCarte.Type.Clubs));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Seven, CCarte.Type.Spades));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Seven, CCarte.Type.Hearts));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Seven, CCarte.Type.Diamonds));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Seven, CCarte.Type.Clubs));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Eight, CCarte.Type.Spades));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Eight, CCarte.Type.Hearts));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Eight, CCarte.Type.Diamonds));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Eight, CCarte.Type.Clubs));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Nine, CCarte.Type.Spades));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Nine, CCarte.Type.Hearts));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Nine, CCarte.Type.Diamonds));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Nine, CCarte.Type.Clubs));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Ten, CCarte.Type.Spades));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Ten, CCarte.Type.Hearts));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Ten, CCarte.Type.Diamonds));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Ten, CCarte.Type.Clubs));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Jack, CCarte.Type.Spades));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Jack, CCarte.Type.Hearts));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Jack, CCarte.Type.Diamonds));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Jack, CCarte.Type.Clubs));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Queen, CCarte.Type.Spades));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Queen, CCarte.Type.Hearts));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Queen, CCarte.Type.Diamonds));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.Queen, CCarte.Type.Clubs));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.King, CCarte.Type.Spades));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.King, CCarte.Type.Hearts));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.King, CCarte.Type.Diamonds));
            FFLstCartes.Add(new CCarte(CCarte.Valeur.King, CCarte.Type.Clubs));
            #endregion
        }
        /// <summary>
        /// Distribuer le nombre de cartes désirés à un joueur spécifique.
        /// </summary>
        /// <param name="_indJoueur">Indice du joueur qu'on veut y distribuer des cartes.</param>
        /// <param name="_nbCartesATirer">Nombre de cartes à donner au joueur.</param>
        private void DistribuerCartes(int _indJoueur, int _nbCartesATirer)
        {
            if (_indJoueur >= FFTabJoueurs.Length ||
                _indJoueur < 0 ||
                _nbCartesATirer <= 0 ||
                _nbCartesATirer > FFLstCartes.Count)
                throw new ArgumentOutOfRangeException();

            int indCarteActuel = 0; // L'indice de la carte tiré "présentement"
            string cartes = null; // Cartes du joueur.

            // Pour générer les cartes aléatoire.
            Random PlateauCarte = new Random(System.DateTime.UtcNow.Millisecond % 105143);
            Thread.Sleep(25);


            // Ajoute une carte aléatoire et l'enlève de la possibilité des cartes à tirer. On le fais une fois ici pour éviter de faire plus tard if (carte == null) [...]
            indCarteActuel = PlateauCarte.Next(FFLstCartes.Count);
            cartes = FFLstCartes.ElementAt(indCarteActuel).ToString();
            FFLstCartes.RemoveAt(indCarteActuel);

            for (int iNbCarte = 1; iNbCarte < _nbCartesATirer; iNbCarte++)
            {
          
                indCarteActuel = PlateauCarte.Next(FFLstCartes.Count);
                cartes = cartes + " " + FFLstCartes.ElementAt(indCarteActuel).ToString();

                // Supprimer la carte dans la liste des cartes.
                FFLstCartes.RemoveAt(indCarteActuel);
            }
            // Remplacement des cartes du joueur par les nouvelles cartes.
            FFTabJoueursCartes[_indJoueur] = cartes;
        }
        /// <summary>
        /// Retourner une carte généré aléatoirement.
        /// </summary>
        /// <returns>Carte généré aléatoirement.</returns>
        private CCarte DistributerUneCarte()
        {
            int indCarteActuel = 0; // L'indice de la carte tiré
            CCarte carte = null; // Représente les cartes du joueur.

            // Création d'un pointeur pour générer les cartes aléatoire.
            Random PlateauCarte = new Random(System.DateTime.UtcNow.Millisecond % 105211);
            Thread.Sleep(25);

            indCarteActuel = PlateauCarte.Next(FFLstCartes.Count);
            // Générer une carte aléatoire et l'insérer dans le tableau des cartes des joueurs.
            carte = FFLstCartes.ElementAt(indCarteActuel);

            // Supprimer la carte dans la liste des cartes.
            FFLstCartes.RemoveAt(indCarteActuel);

            // Remplacement des cartes du joueur par les nouvelles cartes.
            return carte;
        }
        #endregion

        #region Méthodes pour les interfaces
        private void GUIPositionnerDealer()
        {
            if (!FFLstJoueursPasFold.Contains(FFIndPremierJoueurAParlerPostflop))
                throw new InvalidOperationException("Vous devez affecter une donnée valide à la donnée membre FIndPremierJoueurPostflop");

            switch (CListHelper.ElemPrecedent(FFLstJoueursPasFold, FFIndPremierJoueurAParlerPostflop))
            {
                case SB:
                    FFrmJeu.PositionnerDealer(frmJeu.DEALER_POS.SB);
                    break;
                case BB:
                    FFrmJeu.PositionnerDealer(frmJeu.DEALER_POS.BB);
                    break;
                case UTG:
                    FFrmJeu.PositionnerDealer(frmJeu.DEALER_POS.UTG);
                    break;
                case MP:
                    FFrmJeu.PositionnerDealer(frmJeu.DEALER_POS.MP);
                    break;
                case CO:
                    FFrmJeu.PositionnerDealer(frmJeu.DEALER_POS.CO);
                    break;
                case DEALER:
                    FFrmJeu.PositionnerDealer(frmJeu.DEALER_POS.BTN);
                    break;
            }
        }
        public void GUIMettreAJour()
        {
            MettreAJourChoixJoueurTourActuel();

            for (int indJoueur = 0; indJoueur < FFTabJoueurs.Length; ++indJoueur)
            {
                if (indJoueur == FIndJoueurActuel)
                    FFrmJeu.AfficherCartes(indJoueur, FFTabJoueursCartes[indJoueur]);
                // Si le joueur n'a pas folder, alors on souhaite afficher ses cartes (cachés)
                else if (FFLstJoueursPasFold.IndexOf(indJoueur) != -1)
                    FFrmJeu.AfficherCartesCachee(indJoueur);
                else
                    FFrmJeu.CacherCartes(indJoueur);
            }

            FFrmJeu.AfficherPot();

            FFrmJeu.MettreAJourChoixDuJoueur(FLstActionsPossibleJoueurActuel.Contains(ActionsPossible.Fold),
                                             FLstActionsPossibleJoueurActuel.Contains(ActionsPossible.Check),
                                             FLstActionsPossibleJoueurActuel.Contains(ActionsPossible.Call),
                                             FLstActionsPossibleJoueurActuel.Contains(ActionsPossible.Bet),
                                             FLstActionsPossibleJoueurActuel.Contains(ActionsPossible.Raise),
                                             FFTabJoueurs[FIndJoueurActuel].PNbJetons);
        }
        #endregion

        #region Méthodes qui se fait appeler seulement par une interface
        /// <summary>
        /// Effectuer l'action de fold pour le joueur à qui est le tour de jouer.
        /// </summary>
        public void Fold()
        {
            if (!FLstActionsPossibleJoueurActuel.Contains(ActionsPossible.Fold))
                throw new InvalidOperationException("Le joueur n'a pas le droit de faire un Fold!");
            else if (!FFLstJoueursPasFold.Contains(FIndJoueurActuel))
                throw new InvalidOperationException("Vous devez affecter une donnée valide à la donnée membre FIndJoueurActuel");

            // Ajoute à la liste des actions du tour en cours l'action du joueur
            FFLstActionsMainActuel[FFTabJoueurs[FIndJoueurActuel]][(int)FFStadeMain].Add(new CAction(ActionsPossible.Fold));

            FFTabJoueursCartes[FIndJoueurActuel] = "";

            // Mettre à jour le nouveau joueur à parler au prochain tour et enlever le joueur actuel qui a jeté ses cartes
            // des joueurs du tour actuel   
            FIndJoueurActuel = CListHelper.ElemPrecedent(FFLstJoueursPasFold, FIndJoueurActuel);
            FFLstJoueursPasFold.Remove(CListHelper.ElemNextOf(FFLstJoueursPasFold, FIndJoueurActuel));             
            
            JouerTour();
        }
        /// <summary>
        /// Effectuer l'action de check pour le joueur à qui est le tour de jouer.
        /// </summary>
        public void Check()
        {
            if (!FLstActionsPossibleJoueurActuel.Contains(ActionsPossible.Check))
                throw new InvalidOperationException("Le joueur n'a pas le droit de faire un Check!");
            
            // Ajoute à la liste des actions du tour en cours l'action du joueur
            FFLstActionsMainActuel[FFTabJoueurs[FIndJoueurActuel]][(int)FFStadeMain].Add(new CAction(ActionsPossible.Check));

            FFrmJeu.AfficherCheckDunJoueur(FIndJoueurActuel);

            JouerTour();
        }
        /// <summary>
        /// Effectuer l'action de call pour le joueur à qui est le tour de jouer.
        /// </summary>
        public void Call()
        {
            if (!FLstActionsPossibleJoueurActuel.Contains(ActionsPossible.Call))
                throw new InvalidOperationException("Le joueur n'a pas le droit de faire un Call!");
            else if (FFTabJoueurs[FIndJoueurActuel].PNbJetons < (FFDerniereMise - FFTabJoueurs[FIndJoueurActuel].PDerniereMise))
                throw new InvalidOperationException("Le joueur n'a pas assez de jetons pour effectuer un call.");

            // Ajoute à la liste des actions du tour en cours l'action du joueur
            FFLstActionsMainActuel[FFTabJoueurs[FIndJoueurActuel]][(int)FFStadeMain].Add(new CAction(ActionsPossible.Call, FFDerniereMise));

            FFPot = FFPot + (FFDerniereMise - FFTabJoueurs[FIndJoueurActuel].PDerniereMise);
            FFTabJoueurs[FIndJoueurActuel].PNbJetons = (FFTabJoueurs[FIndJoueurActuel].PNbJetons - (FFDerniereMise - FFTabJoueurs[FIndJoueurActuel].PDerniereMise));
            FFTabJoueurs[FIndJoueurActuel].PDerniereMise = FFDerniereMise;

            FFrmJeu.AfficherCallDunJoueur(FIndJoueurActuel);
            FFrmJeu.AfficherNbJetonDunJoueur(FIndJoueurActuel);

            JouerTour();      
        }
        /// <summary>
        /// Effectuer l'action de miser pour le joueur à qui est le tour de jouer.
        /// </summary>
        /// <param name="_mise">Mise du joueur à qui est le tour de jouer.</param>
        public void Bet(double _mise)
        {
            if (!FLstActionsPossibleJoueurActuel.Contains(ActionsPossible.Bet) || (FFDerniereMise > 0))
                throw new InvalidOperationException("Il y a déjà une mise en cours. On ne peut pas miser!");
            else if (FFTabJoueurs[FIndJoueurActuel].PNbJetons < _mise)
                throw new InvalidOperationException("Le joueur n'a pas assez de jetons pour effectuer une telle mise.");

            // Ajoute à la liste des actions du tour en cours l'action du joueur
            FFLstActionsMainActuel[FFTabJoueurs[FIndJoueurActuel]][(int)FFStadeMain].Add(new CAction(ActionsPossible.Bet, _mise));

            FFPot = FFPot + _mise;
            FFDerniereMise = _mise;
            FFTabJoueurs[FIndJoueurActuel].PNbJetons = (FFTabJoueurs[FIndJoueurActuel].PNbJetons - _mise);
            FFTabJoueurs[FIndJoueurActuel].PDerniereMise = _mise;

            FFrmJeu.AfficherMiseDunJoueur(FIndJoueurActuel);
            FFrmJeu.AfficherNbJetonDunJoueur(FIndJoueurActuel);

            FIndDernierJoueurAParler = CListHelper.ElemPrecedent(FFLstJoueursPasFold, FIndJoueurActuel);

            JouerTour();
        }
        /// <summary>
        /// Effectuer l'action de raiser pour le joueur à qui est le tour de jouer.
        /// </summary>
        /// <param name="_mise">Mise du joueur à qui est le tour de jouer.</param>
        public void Raise(double _mise)
        {
            if (!FLstActionsPossibleJoueurActuel.Contains(ActionsPossible.Raise))
                throw new InvalidOperationException("Le joueur n'a pas le droit de faire un Raise!");
            else if ((FFTabJoueurs[FIndJoueurActuel].PNbJetons + FFTabJoueurs[FIndJoueurActuel].PDerniereMise) < _mise)
                throw new InvalidOperationException("Le joueur doit avoir le nombre de jetons nécessaire pour effectuer une relance.");
            else if (_mise < (FFDerniereMise + FFBigBlind))
                throw new InvalidOperationException("La mise doit être au moins un big blind de plus que la dernière mise.");

            // Ajoute à la liste des actions du tour en cours l'action du joueur
            FFLstActionsMainActuel[FFTabJoueurs[FIndJoueurActuel]][(int)FFStadeMain].Add(new CAction(ActionsPossible.Raise, _mise));

            FFPot = FFPot + (_mise - FFTabJoueurs[FIndJoueurActuel].PDerniereMise);
            FFDerniereMise = _mise;
            FFTabJoueurs[FIndJoueurActuel].PNbJetons = (FFTabJoueurs[FIndJoueurActuel].PNbJetons - (_mise - FFTabJoueurs[FIndJoueurActuel].PDerniereMise));
            FFTabJoueurs[FIndJoueurActuel].PDerniereMise = _mise;

            FFrmJeu.AfficherRaiseDunJoueur(FIndJoueurActuel);
            FFrmJeu.AfficherNbJetonDunJoueur(FIndJoueurActuel);

            FIndDernierJoueurAParler = CListHelper.ElemPrecedent(FFLstJoueursPasFold, FIndJoueurActuel);

            JouerTour();
        }
        #endregion
    }
}
