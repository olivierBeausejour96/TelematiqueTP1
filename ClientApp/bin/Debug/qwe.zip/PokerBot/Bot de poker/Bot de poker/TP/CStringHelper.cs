﻿using System;

namespace TP
{
    public static class CStringHelper
    {
        public static CCarte ToCCarte(this string chaineActuel)
        {
            if ((chaineActuel.Length == 2) &&
                (Enum.IsDefined(typeof(CCarte.Valeur), (int)chaineActuel[0]) && Enum.IsDefined(typeof(CCarte.Type), (int)chaineActuel[1])))
                return new CCarte((CCarte.Valeur)chaineActuel[0], (CCarte.Type)chaineActuel[1]);
            else
                throw new ArgumentException();
        }
    }
}
