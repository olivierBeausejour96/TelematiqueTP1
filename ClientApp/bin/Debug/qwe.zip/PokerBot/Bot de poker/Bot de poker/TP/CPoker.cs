﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace TP {
    public class CPoker {
        

        frmCreerPartie FFrmCreerPartie;
        List<CPartie> FLstParties;       // Pointeur qui pointe vers une liste de CPartie qui représente toutes les parties.

        [STAThread]
        static void Main() 
        {
        /*
            Objectif: Démarrer le programme.
        */
            CPoker pProgramme = new CPoker();
        }

        public CPoker()
        /*
            Objectif: Constructeur de la classe. Afficher l'interface principale du programme.
        */
        {
            // Activer les contrôles visuelles de la classe.
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            // Création de l'interface principale.
            FFrmCreerPartie = new frmCreerPartie(this);
            // Création d'une liste des parties.
            FLstParties = new List<CPartie>();
            // Affichage de l'interface principale.
            Application.Run(FFrmCreerPartie);
        }

        public void Close()
        {
            FLstParties.Clear();
            FLstParties = null;
            Application.Exit();
        }

        public void CreerPartie(int _nbJoueurs, int _nbRobots, double _nbJetonsDepart, double _smallBlind, double _bigBlind, double _antes)
        {
            FLstParties.Add(new CPartie(_nbJoueurs, _nbRobots, _nbJetonsDepart, _smallBlind, _bigBlind, _antes));
        }
    }
}
