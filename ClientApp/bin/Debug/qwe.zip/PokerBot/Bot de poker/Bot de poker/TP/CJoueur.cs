﻿namespace TP
{
    public class CJoueur
    {
        /// <summary>
        /// Nombre de jetons
        /// </summary>
        private double FFNbJetons;
        /// <summary>
        /// Dernière mise du joueur
        /// </summary>
        private double FFDerniereMise;

        public double PNbJetons
        {
            get { return FFNbJetons; }
            set { FFNbJetons = value; }
        }

        public double PDerniereMise
        {
            get { return FFDerniereMise; }
            set { FFDerniereMise = value; }
        }

        public CJoueur(double _nbJetons)
        {                                  
            FFNbJetons = _nbJetons;
            FFDerniereMise = 0;
        }
    }
}
