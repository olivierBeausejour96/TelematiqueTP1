﻿namespace TP {
    partial class frmCreerPartie {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.txtNbJetonDepart = new System.Windows.Forms.TextBox();
            this.cmbNbJoueur = new System.Windows.Forms.ComboBox();
            this.lblNbJoueur = new System.Windows.Forms.Label();
            this.lblNbRobot = new System.Windows.Forms.Label();
            this.lblNbJetonDepart = new System.Windows.Forms.Label();
            this.cmbNbRobot = new System.Windows.Forms.ComboBox();
            this.lblAntes = new System.Windows.Forms.Label();
            this.btnCommencerPartie = new System.Windows.Forms.Button();
            this.lblNbMinParNiveau = new System.Windows.Forms.Label();
            this.txtNbMinParNiveau = new System.Windows.Forms.TextBox();
            this.txtAntes = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSmallBlind = new System.Windows.Forms.TextBox();
            this.txtBigBlind = new System.Windows.Forms.TextBox();
            this.dgvRobots = new System.Windows.Forms.DataGridView();
            this.nom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.winRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.preflopRange = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grpSimulation = new System.Windows.Forms.GroupBox();
            this.btnSimuler = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRobots)).BeginInit();
            this.grpSimulation.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtNbJetonDepart
            // 
            this.txtNbJetonDepart.Location = new System.Drawing.Point(171, 164);
            this.txtNbJetonDepart.MaxLength = 7;
            this.txtNbJetonDepart.Name = "txtNbJetonDepart";
            this.txtNbJetonDepart.Size = new System.Drawing.Size(102, 20);
            this.txtNbJetonDepart.TabIndex = 5;
            this.txtNbJetonDepart.Text = "100";
            this.txtNbJetonDepart.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMinuteJetonNiveau_KeyPress);
            // 
            // cmbNbJoueur
            // 
            this.cmbNbJoueur.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNbJoueur.FormattingEnabled = true;
            this.cmbNbJoueur.Items.AddRange(new object[] {
            "2",
            "3",
            "4",
            "5",
            "6"});
            this.cmbNbJoueur.Location = new System.Drawing.Point(171, 6);
            this.cmbNbJoueur.Name = "cmbNbJoueur";
            this.cmbNbJoueur.Size = new System.Drawing.Size(102, 21);
            this.cmbNbJoueur.Sorted = true;
            this.cmbNbJoueur.TabIndex = 1;
            this.cmbNbJoueur.SelectedIndexChanged += new System.EventHandler(this.cmbNbJoueur_SelectedIndexChanged);
            // 
            // lblNbJoueur
            // 
            this.lblNbJoueur.AutoSize = true;
            this.lblNbJoueur.Location = new System.Drawing.Point(14, 6);
            this.lblNbJoueur.Name = "lblNbJoueur";
            this.lblNbJoueur.Size = new System.Drawing.Size(96, 13);
            this.lblNbJoueur.TabIndex = 7;
            this.lblNbJoueur.Text = "Nombre de joueurs";
            // 
            // lblNbRobot
            // 
            this.lblNbRobot.AutoSize = true;
            this.lblNbRobot.Location = new System.Drawing.Point(14, 33);
            this.lblNbRobot.Name = "lblNbRobot";
            this.lblNbRobot.Size = new System.Drawing.Size(91, 13);
            this.lblNbRobot.TabIndex = 8;
            this.lblNbRobot.Text = "Nombre de robots";
            // 
            // lblNbJetonDepart
            // 
            this.lblNbJetonDepart.AutoSize = true;
            this.lblNbJetonDepart.Location = new System.Drawing.Point(14, 164);
            this.lblNbJetonDepart.Name = "lblNbJetonDepart";
            this.lblNbJetonDepart.Size = new System.Drawing.Size(138, 13);
            this.lblNbJetonDepart.TabIndex = 9;
            this.lblNbJetonDepart.Text = "Nombre de jetons au départ";
            // 
            // cmbNbRobot
            // 
            this.cmbNbRobot.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNbRobot.FormattingEnabled = true;
            this.cmbNbRobot.Items.AddRange(new object[] {
            "0",
            "1",
            "2"});
            this.cmbNbRobot.Location = new System.Drawing.Point(171, 33);
            this.cmbNbRobot.Name = "cmbNbRobot";
            this.cmbNbRobot.Size = new System.Drawing.Size(102, 21);
            this.cmbNbRobot.Sorted = true;
            this.cmbNbRobot.TabIndex = 2;
            this.cmbNbRobot.SelectedIndexChanged += new System.EventHandler(this.cmbNbRobot_SelectedIndexChanged);
            // 
            // lblAntes
            // 
            this.lblAntes.AutoSize = true;
            this.lblAntes.Enabled = false;
            this.lblAntes.Location = new System.Drawing.Point(14, 63);
            this.lblAntes.Name = "lblAntes";
            this.lblAntes.Size = new System.Drawing.Size(34, 13);
            this.lblAntes.TabIndex = 14;
            this.lblAntes.Text = "Antes";
            // 
            // btnCommencerPartie
            // 
            this.btnCommencerPartie.Location = new System.Drawing.Point(12, 196);
            this.btnCommencerPartie.Name = "btnCommencerPartie";
            this.btnCommencerPartie.Size = new System.Drawing.Size(256, 67);
            this.btnCommencerPartie.TabIndex = 9;
            this.btnCommencerPartie.Text = "Commencer la partie";
            this.btnCommencerPartie.UseVisualStyleBackColor = true;
            this.btnCommencerPartie.Click += new System.EventHandler(this.btnCommencerPartie_Click);
            // 
            // lblNbMinParNiveau
            // 
            this.lblNbMinParNiveau.AutoSize = true;
            this.lblNbMinParNiveau.Enabled = false;
            this.lblNbMinParNiveau.Location = new System.Drawing.Point(14, 137);
            this.lblNbMinParNiveau.Name = "lblNbMinParNiveau";
            this.lblNbMinParNiveau.Size = new System.Drawing.Size(151, 13);
            this.lblNbMinParNiveau.TabIndex = 19;
            this.lblNbMinParNiveau.Text = "Nombre de minutes par niveau";
            // 
            // txtNbMinParNiveau
            // 
            this.txtNbMinParNiveau.Enabled = false;
            this.txtNbMinParNiveau.Location = new System.Drawing.Point(171, 137);
            this.txtNbMinParNiveau.MaxLength = 3;
            this.txtNbMinParNiveau.Name = "txtNbMinParNiveau";
            this.txtNbMinParNiveau.Size = new System.Drawing.Size(102, 20);
            this.txtNbMinParNiveau.TabIndex = 4;
            this.txtNbMinParNiveau.Text = "10";
            this.txtNbMinParNiveau.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMinuteJetonNiveau_KeyPress);
            // 
            // txtAntes
            // 
            this.txtAntes.Enabled = false;
            this.txtAntes.Location = new System.Drawing.Point(171, 63);
            this.txtAntes.MaxLength = 3;
            this.txtAntes.Name = "txtAntes";
            this.txtAntes.Size = new System.Drawing.Size(102, 20);
            this.txtAntes.TabIndex = 20;
            this.txtAntes.Text = "0";
            this.txtAntes.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMinuteJetonNiveau_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 89);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 21;
            this.label1.Text = "Small blind";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 113);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 22;
            this.label2.Text = "Big blind";
            // 
            // txtSmallBlind
            // 
            this.txtSmallBlind.Location = new System.Drawing.Point(171, 89);
            this.txtSmallBlind.MaxLength = 3;
            this.txtSmallBlind.Name = "txtSmallBlind";
            this.txtSmallBlind.Size = new System.Drawing.Size(102, 20);
            this.txtSmallBlind.TabIndex = 23;
            this.txtSmallBlind.Text = "0.50";
            // 
            // txtBigBlind
            // 
            this.txtBigBlind.Location = new System.Drawing.Point(171, 113);
            this.txtBigBlind.MaxLength = 3;
            this.txtBigBlind.Name = "txtBigBlind";
            this.txtBigBlind.Size = new System.Drawing.Size(102, 20);
            this.txtBigBlind.TabIndex = 24;
            this.txtBigBlind.Text = "1";
            // 
            // dgvRobots
            // 
            this.dgvRobots.AllowUserToAddRows = false;
            this.dgvRobots.AllowUserToDeleteRows = false;
            this.dgvRobots.AllowUserToResizeColumns = false;
            this.dgvRobots.AllowUserToResizeRows = false;
            this.dgvRobots.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRobots.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nom,
            this.winRate,
            this.preflopRange});
            this.dgvRobots.Location = new System.Drawing.Point(279, 6);
            this.dgvRobots.Name = "dgvRobots";
            this.dgvRobots.ReadOnly = true;
            this.dgvRobots.RowHeadersVisible = false;
            this.dgvRobots.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dgvRobots.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvRobots.Size = new System.Drawing.Size(400, 178);
            this.dgvRobots.TabIndex = 0;
            this.dgvRobots.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvRobots_CellMouseDown);
            // 
            // nom
            // 
            this.nom.HeaderText = "Nom";
            this.nom.Name = "nom";
            this.nom.ReadOnly = true;
            // 
            // winRate
            // 
            this.winRate.HeaderText = "Win rate (bb/100)";
            this.winRate.Name = "winRate";
            this.winRate.ReadOnly = true;
            // 
            // preflopRange
            // 
            this.preflopRange.HeaderText = "Preflop range";
            this.preflopRange.Name = "preflopRange";
            this.preflopRange.ReadOnly = true;
            // 
            // grpSimulation
            // 
            this.grpSimulation.Controls.Add(this.btnSimuler);
            this.grpSimulation.Controls.Add(this.label3);
            this.grpSimulation.Controls.Add(this.textBox3);
            this.grpSimulation.Controls.Add(this.textBox2);
            this.grpSimulation.Controls.Add(this.textBox1);
            this.grpSimulation.Location = new System.Drawing.Point(279, 190);
            this.grpSimulation.Name = "grpSimulation";
            this.grpSimulation.Size = new System.Drawing.Size(400, 73);
            this.grpSimulation.TabIndex = 25;
            this.grpSimulation.TabStop = false;
            this.grpSimulation.Text = "Simulation";
            // 
            // btnSimuler
            // 
            this.btnSimuler.Location = new System.Drawing.Point(298, 19);
            this.btnSimuler.Name = "btnSimuler";
            this.btnSimuler.Size = new System.Drawing.Size(96, 46);
            this.btnSimuler.TabIndex = 4;
            this.btnSimuler.Text = "Simuler";
            this.btnSimuler.UseVisualStyleBackColor = true;
            this.btnSimuler.Click += new System.EventHandler(this.btnSimuler_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(106, 30);
            this.label3.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "___________";
            // 
            // textBox3
            // 
            this.textBox3.Enabled = false;
            this.textBox3.Location = new System.Drawing.Point(179, 32);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(112, 20);
            this.textBox3.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Enabled = false;
            this.textBox2.Location = new System.Drawing.Point(6, 45);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 1;
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(6, 19);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 0;
            // 
            // frmCreerPartie
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(691, 269);
            this.Controls.Add(this.grpSimulation);
            this.Controls.Add(this.dgvRobots);
            this.Controls.Add(this.txtBigBlind);
            this.Controls.Add(this.txtSmallBlind);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtAntes);
            this.Controls.Add(this.txtNbMinParNiveau);
            this.Controls.Add(this.lblNbMinParNiveau);
            this.Controls.Add(this.btnCommencerPartie);
            this.Controls.Add(this.lblAntes);
            this.Controls.Add(this.cmbNbRobot);
            this.Controls.Add(this.lblNbJetonDepart);
            this.Controls.Add(this.lblNbRobot);
            this.Controls.Add(this.lblNbJoueur);
            this.Controls.Add(this.cmbNbJoueur);
            this.Controls.Add(this.txtNbJetonDepart);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmCreerPartie";
            this.ShowIcon = false;
            this.Text = "Amigo 0.1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmCreerPartie_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRobots)).EndInit();
            this.grpSimulation.ResumeLayout(false);
            this.grpSimulation.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNbJetonDepart;
        private System.Windows.Forms.ComboBox cmbNbJoueur;
        private System.Windows.Forms.Label lblNbJoueur;
        private System.Windows.Forms.Label lblNbRobot;
        private System.Windows.Forms.Label lblNbJetonDepart;
        private System.Windows.Forms.ComboBox cmbNbRobot;
        private System.Windows.Forms.Label lblAntes;
        private System.Windows.Forms.Button btnCommencerPartie;
        private System.Windows.Forms.Label lblNbMinParNiveau;
        private System.Windows.Forms.TextBox txtNbMinParNiveau;
        private System.Windows.Forms.TextBox txtAntes;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtSmallBlind;
        private System.Windows.Forms.TextBox txtBigBlind;
        private System.Windows.Forms.DataGridView dgvRobots;
        private System.Windows.Forms.DataGridViewTextBoxColumn nom;
        private System.Windows.Forms.DataGridViewTextBoxColumn winRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn preflopRange;
        private System.Windows.Forms.GroupBox grpSimulation;
        private System.Windows.Forms.Button btnSimuler;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
    }
}