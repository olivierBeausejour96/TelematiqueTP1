﻿using System;
using System.Collections.Generic;

using static TP.CPartie;

namespace TP
{
    /// <summary>
    /// Robot qui va jouer pour nous.
    /// </summary>
    public abstract class CBotSite
    {
        /// <summary>
        /// Liste de toutes les tables ouvertes dirigé par le bot.
        /// Clé: Joueur (avec notre stack, etc) de la table
        /// </summary>
        private Dictionary<CJoueur, CTableInfosNLHE2Max> FFLstTablesNLHE2Max;
        /// <summary>
        /// Listes de toutes les tables ouvertes, qui requièrent une action en cours, dirigé par le bot. 
        /// Les tables sont en ordre de priorité (la première de la file est la plus urgente).
        /// </summary>
        private Queue<CTableInfosNLHE2Max> FFLstTablesPrioriteNLHE2Max;

        public CTableInfosNLHE2Max getTablePlusUrgenteNLHE2Max()
        {
            return FFLstTablesPrioriteNLHE2Max.Dequeue();
        }

        public CBotSite()
        {
            FFLstTablesNLHE2Max = new Dictionary<CJoueur, CTableInfosNLHE2Max>();
            FFLstTablesPrioriteNLHE2Max = new Queue<CTableInfosNLHE2Max>();
        }

        /// <summary>
        /// Ajouter une table PRÉSENTEMENT OUVERTE du site dans la liste des tables.
        /// </summary>
        /// <param name="_joueurTable">Joueur correspondant à la table (c'est nous sur la table). Le joueur représente la table.</param>
        /// <param name="_table">Table que l'on souhaite ajouter. Contient toutes les informations de la nouvelle table ouverte.</param>
        public void AjouterTableNLHE2Max(CJoueur _joueurTable, CTableInfosNLHE2Max _table)
        {
            FFLstTablesNLHE2Max.Add(_joueurTable, _table);
        }
        /// <summary>
        /// Ajoute une action qui vient de se produire dans une table présentement ouverte.
        /// Pour l'instant, cette fonction est supposé d'être globale (pour tout sorte de table) mais ne supporte juste le 2-max (heads-up).
        /// </summary>
        /// <param name="_joueurTable">Joueur qui est associé à une table X.</param>
        /// <param name="_joueurAction">Joueur qui a fait l'action X (Fold, Check, Bet, etc)</param>
        /// <param name="_action">Action qui s'est passé à la table</param>
        /// <param name="_tour">Tour actuel (preflop, flop, turn ou river) de la table</param>
        public void AjouterAction(CJoueur _joueurTable, CJoueur _joueurAction, CAction _action, ToursPossible _tour)
        {
            if (!FFLstTablesNLHE2Max.ContainsKey(_joueurTable))
                throw new ArgumentException("Il n'existe pas de table associé à ce joueur!");
            
            FFLstTablesNLHE2Max[_joueurTable].AjouterAction(_joueurAction, _action, _tour);
        }

        /// <summary>
        /// Démarrer le robot qui ouvre, ferme, détecte notre main, détecte les mises des mains, etc
        /// </summary>
        public abstract void Demarrer();
        /// <summary>
        /// Arrêter toute action du robot.
        /// </summary>
        public abstract void Arreter();

        /// <summary>
        /// Effectuer l'action de fold sur le site.
        /// </summary>
        /// <param name="_joueurTable">Table X que l'on accède à l'aide du joueur (le joueur est nous-même). Lire autre code si ce n'est pas clair.</param>
        public abstract void Fold(CJoueur _joueurTable);
        /// <summary>
        /// Effectuer l'action de check sur le site.
        /// </summary>
        /// <param name="_joueurTable">Table X que l'on accède à l'aide du joueur (le joueur est nous-même). Lire autre code si ce n'est pas clair.</param>
        public abstract void Check(CJoueur _joueurTable);
        /// <summary>
        /// Effectuer l'action de bet sur le site.
        /// </summary>
        /// <param name="_joueurTable">Table X que l'on accède à l'aide du joueur (le joueur est nous-même). Lire autre code si ce n'est pas clair.</param>
        public abstract void Bet(CJoueur _joueurTable);
        /// <summary>
        /// Effectuer l'action de call sur le site.
        /// </summary>
        /// <param name="_joueurTable">Table X que l'on accède à l'aide du joueur (le joueur est nous-même). Lire autre code si ce n'est pas clair.</param>
        public abstract void Call(CJoueur _joueurTable);
        /// <summary>
        /// Effectuer l'action de raise sur le site.
        /// </summary>
        /// <param name="_joueurTable">Table X que l'on accède à l'aide du joueur (le joueur est nous-même). Lire autre code si ce n'est pas clair.</param>
        public abstract void Raise(CJoueur _joueurTable);       
    }
}
