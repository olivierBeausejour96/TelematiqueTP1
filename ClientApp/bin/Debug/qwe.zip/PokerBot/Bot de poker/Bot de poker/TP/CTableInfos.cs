﻿using System;
using static TP.CPartie;

namespace TP
{
    /// <summary>
    /// Informations sur une table de poker ouverte "présentement" sur un ordinateur.
    /// </summary>
    public abstract class CTableInfos
    {        
        private double FFSmallBlind;

        public double PSmallBlind
        {
            get { return FFSmallBlind; }
        }

        private double FFBigBlind;

        public double PBigBlind
        {
            get { return FFBigBlind; }
        }

        private double FFAntes;

        public double PAntes
        {
            get { return FFAntes; }
        }

        private double FFPosX;
        /// <summary>
        /// Position sur l'axe des X de la table par rapport à la fenêtre.
        /// </summary>
        public double PPosX
        {
            set { FFPosX = value; }
            get { return FFPosX; }
        }

        private double FFPosY;
        /// <summary>
        /// Position sur l'axe des Y de la table par rapport à la fenêtre.
        /// </summary>
        public double PPosY
        {
            set { FFPosY = value; }
            get { return FFPosY; }
        }

        public CTableInfos(double _smallBlind, double _bigBlind, double _antes, double _posX, double _posY)
        {
            if (_smallBlind < 0)
                throw new ArgumentException("Le small blind doit être supérieur ou égal à 0.");
            else if (_bigBlind < 0)
                throw new ArgumentException("Le big blind doit être supérieur ou égal à 0.");
            else if (_antes < 0)
                throw new ArgumentException("Les antes doit être supérieur ou égal à 0.");

            FFSmallBlind = _smallBlind;
            FFBigBlind = _bigBlind;
            FFAntes = _antes;
            FFPosX = _posX;
            FFPosY = _posY;
        }

        public abstract ToursPossible getTourActuel();
        public abstract TypesPot getTypePot();
    }
}
